cd /Users/alexispurslane/.t3/worktrees/tertius/t3-be96064f-5ee56be7a03e478c
nix develop --command bash tools/cleanup.sh src/Tertius.Rendering/Vulkan/DeviceAllocator.cs tests/Tertius.Rendering.Tests/DeviceAllocatorTests.cs > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/cleanup/command.log' 2>&1
status=$?
printf "%s\n" "$status" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/cleanup/exit.txt'
exit "$status"
