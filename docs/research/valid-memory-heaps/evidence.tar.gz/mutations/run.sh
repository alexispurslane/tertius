cd /Users/alexispurslane/.t3/worktrees/tertius/t3-be96064f-5ee56be7a03e478c
nix develop --command python3 -I tools/mutate.py '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutants.json' '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutation-results' --allow-staged > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutations/command.log' 2>&1
status=$?
printf "%s\n" "$status" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutations/exit.txt'
exit "$status"
