cd /Users/alexispurslane/.t3/worktrees/tertius/t3-be96064f-5ee56be7a03e478c
nix develop --command python3 -I tools/mutate.py '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutants-final.json' '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutation-M01-results' --allow-staged --only M01 > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutation-M01/command.log' 2>&1
status=$?
printf "%s\n" "$status" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/mutation-M01/exit.txt'
exit "$status"
