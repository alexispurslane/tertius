cd /Users/alexispurslane/.t3/worktrees/tertius/t3-be96064f-5ee56be7a03e478c
nix develop --command dotnet test --project tests/Tertius.Rendering.Tests -c Checked --filter-class '*.DeviceAllocatorTests' --coverage --coverage-output-format cobertura --coverage-output Rendering.cobertura.xml --results-directory '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/coverage/results' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/coverage/command.log' 2>&1
status=$?
printf "%s\n" "$status" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/coverage/exit.txt'
exit "$status"
