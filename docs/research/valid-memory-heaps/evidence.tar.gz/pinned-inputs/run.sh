cd /Users/alexispurslane/.t3/worktrees/tertius/t3-be96064f-5ee56be7a03e478c
nix develop --command python3 -I '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/verify-pinned-inputs.py' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/pinned-inputs/command.log' 2>&1
status=$?
printf "%s\n" "$status" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-35-evidence/pinned-inputs/exit.txt'
exit "$status"
