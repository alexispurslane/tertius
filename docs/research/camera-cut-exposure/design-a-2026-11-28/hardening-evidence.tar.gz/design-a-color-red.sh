#!/bin/bash
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
nix develop --command dotnet test --project tests/Tertius.Rendering.Tests -c Checked --filter-class '*.ReflectionSharingTests' --filter-method 'SharingRetainsTinyColorChannelsBesideABrightColorChannel' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-color-red.log' 2>&1
code=$?
printf '%s\n' "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-color-red.exit'
exit "$code"
