#!/bin/bash
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
nix develop --command dotnet test --project tests/Tertius.Rendering.Tests -c Checked --filter-class '*.GlossySceneRadianceTests' --filter-class '*SceneRadianceFiltering' --filter-class '*.AccumulatorRenderTests*' --filter-class '*.ScreenTraceHardeningTests*' --filter-class '*.ReflectionSharingTests*' --filter-class '*.ResolveSharedReflectionTests' --filter-class '*.ShaderVariantTests' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-range2.log' 2>&1
code=$?
printf '%s\n' "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-range2.exit'
exit "$code"
