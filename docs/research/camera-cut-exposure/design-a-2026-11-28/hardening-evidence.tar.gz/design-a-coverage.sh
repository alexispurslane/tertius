#!/bin/bash
set -e
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
finish() { code=$?; printf "%s\n" "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage.exit'; }
trap finish EXIT
nix develop --command dotnet test --project tests/Tertius.Rendering.Tests -c Checked --filter-class '*.ReflectionSharingTests*' --filter-class '*.AmbientCutSourceTests' --filter-class '*.AmbientReflectionSourceTests' --filter-class '*.GlossySceneRadianceTests' --filter-class '*SceneRadianceFiltering' --filter-class '*CutHistoryExposure' --filter-class '*.AccumulatorRenderTests' --filter-class '*.AmbientSkipsTests' --filter-class '*.ScreenTraceHardeningTests' --coverage --coverage-output-format cobertura --coverage-output Rendering.cobertura.xml --results-directory '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage/Checked' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage.log' 2>&1
