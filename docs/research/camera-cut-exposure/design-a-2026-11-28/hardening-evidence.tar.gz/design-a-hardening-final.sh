#!/bin/bash
set -e
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
finish() { code=$?; printf "%s\n" "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-hardening-final.exit'; }
trap finish EXIT
nix develop --command csharpier format tests/Tertius.Rendering.Tests/AccumulatorSceneRadianceTests.cs > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-parity-format.log' 2>&1
git add -- tests/Tertius.Rendering.Tests/AccumulatorSceneRadianceTests.cs
python3 - <<'PY2'
import json,hashlib,pathlib
r=pathlib.Path('/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence')
h=json.loads((r/"design-a-verified-source-sha256.json").read_text())
h={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in h}
(r/"design-a-hardened-source-sha256.json").write_text(json.dumps(h,indent=2)+"\n")
PY2
bash '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-mutations-replacements.sh'
nix develop --command dotnet test --project tests/Tertius.Rendering.Tests -c Checked --no-build --filter-class '*SceneRadianceFiltering' --filter-method EachGlossyFastHistoryParityUsesTheLastCompletedDraw --coverage --coverage-output-format cobertura --coverage-output Rendering.cobertura.xml --results-directory '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage/Parity' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-parity-green.log' 2>&1
bash '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage-additional.sh'
