#!/bin/bash
set -e
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
finish() { code=$?; printf "%s\n" "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-hardening-complete.exit'; }
trap finish EXIT
nix develop --command dotnet test --project tests/Tertius.Rendering.Tests -c Checked --no-build --filter-class '*SceneRadianceFiltering' --filter-method '*EachGlossyFastHistoryParityUsesTheLastCompletedDraw*' --coverage --coverage-output-format cobertura --coverage-output Rendering.cobertura.xml --results-directory '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage/Parity' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-parity-green-corrected.log' 2>&1
bash '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage-additional.sh'
