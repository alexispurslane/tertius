import json, os, pathlib, subprocess, sys, datetime
root = pathlib.Path(__file__).parent
worktree = pathlib.Path('/Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236')
def run(name, command, extra=None):
    env = os.environ.copy()
    env['TERTIUS_CONTENT_ROOT'] = '/Users/alexispurslane/Development/tertius/content'
    if extra: env.update(extra)
    with (root / (name + '.log')).open('w') as log:
        code = subprocess.run(['nix', 'develop', '--command', *command], cwd=worktree, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    (root / (name + '.exit')).write_text(str(code) + '\n')
    print(name, code, flush=True)
    if code: sys.exit(code)
run('design-a-captures-build', ['dotnet', 'build', 'tests/Tertius.Host.Tests', '-c', 'Checked'])
for mode in ['native', 'fsr']:
    for control in ['film', 'outside', 'return']:
        name = 'design-a-capture-' + mode + '-' + control
        run(name, ['dotnet', 'test', '--project', 'tests/Tertius.Host.Tests', '-c', 'Checked', '--no-build', '--filter-class', '*.CameraCutSceneMeasurements', '--explicit', 'only'], {'TERTIUS_CUT_REPORT': str(root / 'design-a-captures' / mode / control), 'TERTIUS_CUT_CONTROL': control, 'TERTIUS_CUT_FSR': str(int(mode == 'fsr')), 'TERTIUS_CUT_WINDOW': str(int(mode == 'window'))})
