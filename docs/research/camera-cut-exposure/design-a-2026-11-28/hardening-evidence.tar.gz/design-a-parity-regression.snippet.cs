        [Theory]
        [InlineData("original")]
        [InlineData("precise-capped")]
        [InlineData("precise-uncapped")]
        public void EachGlossyFastHistoryParityUsesTheLastCompletedDraw(string mode)
        {
            string? previousMode = Environment.GetEnvironmentVariable("TERTIUS_SPECULAR_HISTORY");
            VulkanRenderer? renderer = null;
            try
            {
                Environment.SetEnvironmentVariable("TERTIUS_SPECULAR_HISTORY", mode);
                (VulkanRenderer created, SamplePass sample, RenderSnapshot scene) = Accumulating(
                    parameters: SignalParameters.Specular(0),
                    roughness: 0.8f
                );
                renderer = created;
                float[] radiances = [1e20f, 3e20f, 5e20f, 7e20f];
                float[] expectedMeans = [1e20f, 2e20f, 3e20f, 4e20f];
                for (int frame = 0; frame < radiances.Length; frame++)
                {
                    sample.Value = new(new Vector3(radiances[frame]), 1);
                    if (frame == 0)
                        renderer.Render(scene, 1);
                    else
                        Continue(renderer, scene, frames: 1);
                    FastOf(renderer, sample)[4 * Center]
                        .Should()
                        .BeApproximately(expectedMeans[frame], expectedMeans[frame] * 1e-5f);
                    CenterOf(renderer, sample, 0)
                        .Light.X.Should()
                        .BeApproximately(expectedMeans[frame], expectedMeans[frame] * 1e-5f);
                }
            }
            finally
            {
                Environment.SetEnvironmentVariable("TERTIUS_SPECULAR_HISTORY", previousMode);
                if (renderer is not null)
                    Gpu.DisposeAndAssertClean(renderer);
            }
        }
