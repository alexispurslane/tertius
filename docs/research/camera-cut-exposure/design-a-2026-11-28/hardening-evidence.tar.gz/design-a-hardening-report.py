"""Combine the final scripted outcomes with retained, explicitly dated prior evidence."""
from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent
assert (r/'design-a-hardening-complete.exit').read_text().strip()=='0'
first=json.loads((r/'design-a-mutations/results.json').read_text())
second=json.loads((r/'design-a-mutations-replacements/results.json').read_text())
assert first['stopped'] is None and second['stopped'] is None
rows={x['id']:x for x in first['rows']}
for x in second['rows']:rows[x['id']]=x
assert len(rows)==20 and all(x['result']=='killed' for x in rows.values())
assert subprocess.check_output(['git','diff','--name-only','cf84f02bc5fabfedb22c2b17835ae0d194c4cb91','--','src/Tertius.Core','src/Tertius.Simulation'],text=True)==''
h=json.loads((r/'design-a-hardened-source-sha256.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in h.items())
o=json.loads(Path('docs/research/camera-cut-exposure/official-hardening-2026-11-28.json').read_text())
prior=o['scripted_rows']; table=[]
for x in prior:
 x=x.copy();x['evidence']='retained prior run; unchanged behavior'
 if x['id']=='S24':
  x.update(result='removed',resolution='Design A removes glossy exposure conversion. A08 and A11 test the new scene-radiance requirement.',evidence='retired expectation; not counted')
 elif x['id']=='S23':x['resolution']='Retained for diffuse light only; the diffuse producing-exposure conversion is unchanged.'
 table.append(x)
for x in o['official_classifications']:table.append(dict(x,evidence='retained official Stryker run; exact Core/Simulation source unchanged'))
for x in rows.values():table.append(dict(x,evidence='current Design A scripted run'))
report=dict(scope='Design A changed Rendering behavior',current_counts=dict(killed=20,survived=0,timeout=0,no_coverage=0,build_failed=0,no_tests=0),current_mutation_score=1.0,initial_attempt_counts=dict(killed=15,survived=1,build_failed=4),initial_attempt_resolution={'A04':'Replaced the compiler-rejected unused-argument mutation with a compilable wrong scratch descriptor.','A05':'Added a changing-radiance regression; the parity fault returns 1.5e20 instead of the independent 2e20 mean in every mode.','A07':'Replaced a nonexistent overload with preExposed(light).','A09':'Replaced a nonexistent overload with preExposed(reflection).','A10':'Replaced a nonexistent overload with preExposed(glowAt(q)).'},current_rows=list(rows.values()),unified_rows=table,retained_scripted_kills=42,retired=['S24'],official_mutation_score=None,official_reuse_reason='Core and Simulation source is byte-identical to the recorded official run; no executable official mutant ran then.',restoration='Both scripted runs verified exact source/mode/index/HEAD/merge restoration and rebuilt the normal assembly; independent hashes also match.',glsl_line_coverage='Excluded: Microsoft code coverage instruments managed C# only. Listed GPU behavior faults cover shader unit, range, format, history, sharing, composition and metadata failures.',soak='No new soak or MTBF claim; bounded GPU correctness and scripted-fault tests.',source_sha256=h)
(r/'design-a-hardening-summary.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['| ID | Evidence | Change | Outcome | Test or reason |','|---|---|---|---|---|']
for x in table:
 why=x.get('resolution') or ', '.join(x.get('killed_by',[])[:3])
 lines.append('| '+' | '.join(str(v).replace('|','\\|').replace('\n',' ') for v in [x['id'],x['evidence'],x['change'],x['result'],why])+' |')
(r/'design-a-unified-mutant-table.md').write_text('\n'.join(lines)+'\n')
print('20/20 current scripted faults killed; 42 prior kills retained, S24 retired; 3 official no-mutant classifications retained without a score.')
