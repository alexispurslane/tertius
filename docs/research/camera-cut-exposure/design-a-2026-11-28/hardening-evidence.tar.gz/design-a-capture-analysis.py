"""Check the final native/FSR game captures against independent destination controls."""
from pathlib import Path
import hashlib,json,math
root=Path(__file__).parent
folder=root/'design-a-captures'
rows=[];manifest=[]
for mode,extent in [('native',[1280,720]),('fsr',[848,477])]:
 film=json.loads((folder/mode/'film/readings.json').read_text())
 assert film['OutputWidth']==1280 and film['OutputHeight']==720
 assert film['Validation']==[] and len(film['Frames'])==49
 assert film['Clock']=='headless film clock'
 for destination,tick in [('outside',1417),('return',1462)]:
  frame=next(x for x in film['Frames'] if x['Capture']==destination+'-000000')
  control=json.loads((folder/mode/destination/'readings.json').read_text())
  assert len(control['Frames'])==9 and control['Validation']==[]
  cold,settled=control['Frames'][0],control['Frames'][-1]
  assert frame['Tick']==tick and cold['Tick']==tick and settled['Tick']==tick
  assert frame['DestinationShadingDraws']==1 and frame['Presentations']==1
  assert [frame['ActiveWidth'],frame['ActiveHeight']]==extent
  used=frame['Exposure']['Stops'];expected=settled['Exposure']['Stops']
  assert abs(used-frame['SceneTargetStops'])<=1/16
  assert abs(used-expected)<=1/16
  assert max(abs(a-b) for a,b in zip(frame['CenterSrgb'],settled['CenterSrgb']))<=2
  assert all(math.isfinite(x) for x in frame['CenterSceneRadiance'])
  assert math.isfinite(frame['MaximumSceneRadiance'])
  rows.append(dict(mode=mode,destination=destination,tick=tick,used_stops=used,raw_target_stops=frame['SceneTargetStops'],independent_cold_stops=cold['Exposure']['Stops'],independent_settled_stops=expected,center_scene_radiance=frame['CenterSceneRadiance'],center_srgb=frame['CenterSrgb'],reference_center_srgb=settled['CenterSrgb'],draws=frame['DestinationShadingDraws'],presentations=frame['Presentations'],render_extent=extent,output_extent=[1280,720],png=str(folder/mode/'film'/(destination+'-000000.png'))))
 for p in sorted((folder/mode).rglob('*.png')):
  manifest.append(dict(path=str(p.relative_to(folder)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert len(manifest)==134
report=dict(status='passed',platform='Mac Vulkan; offscreen presentation',total_pngs=134,rows=rows,png_manifest=manifest,performance_claim=False)
(root/'design-a-film-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='png_manifest'},indent=2))
