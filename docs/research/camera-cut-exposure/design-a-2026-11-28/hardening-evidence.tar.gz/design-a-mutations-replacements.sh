#!/bin/bash
set -e
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
finish() { code=$?; printf "%s\n" "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-mutations-replacements.exit'; }
trap finish EXIT
nix develop --command python3 -I tools/mutate.py '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-mutants-replacements.json' '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-mutations-replacements' --allow-staged > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-mutations-replacements.log' 2>&1
