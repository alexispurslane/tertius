#!/bin/bash
set -e
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
finish() { code=$?; printf "%s\n" "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage-additional.exit'; }
trap finish EXIT
nix develop --command dotnet test --project tests/Tertius.Rendering.Tests -c Checked --no-build --filter-class '*PreciseHistoryRayAllocation' --filter-class '*.DeviceAllocatorTests' --coverage --coverage-output-format cobertura --coverage-output Rendering.cobertura.xml --results-directory '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage/Additional' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-coverage-additional.log' 2>&1
