"""Report instrumented changed C# lines, including the staged Design A implementation."""
import collections,json,pathlib,re,subprocess,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).parent
worktree=pathlib.Path('/Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236')
base='468dc19d0f5e247819f24bfaea297919439c7b4f'
xmls=list((root/'design-a-coverage').rglob('*.cobertura.xml'))
hits=collections.defaultdict(dict); branches=collections.defaultdict(dict)
for xml in xmls:
 for c in ET.parse(xml).getroot().iter('class'):
  file=c.get('filename','')
  for line in c.findall('./lines/line'):
   n=int(line.get('number'));hits[file][n]=max(hits[file].get(n,0),int(line.get('hits')))
   if (v:=line.get('condition-coverage')):
    a,b=map(int,re.search(r'\((\d+)/(\d+)\)',v).groups());old=branches[file].get(n,(0,0))
    if a>=old[0]:branches[file][n]=(a,b)
diff=subprocess.check_output(['git','diff','--unified=0',base,'--','src'],cwd=worktree,text=True)
changes=collections.defaultdict(set);file=None
for l in diff.splitlines():
 if l.startswith('+++ b/'):file=l[6:]
 if l.startswith('@@'):
  m=re.search(r'\+(\d+)(?:,(\d+))?',l);start=int(m[1]);count=int(m[2] or '1');changes[file].update(range(start,start+count))
rows=[]
for file,nums in sorted(changes.items()):
 if not file.endswith('.cs'):continue
 h=hits[str(worktree/file)];b=branches[str(worktree/file)];inst=nums&h.keys();bn=nums&b.keys()
 rows.append(dict(file=file,changed_lines=sorted(nums),instrumented=len(inst),covered=sum(h[n]>0 for n in inst),uncovered=sorted(n for n in inst if not h[n]),covered_branches=sum(b[n][0] for n in bn),total_branches=sum(b[n][1] for n in bn),partial_branches={n:b[n] for n in sorted(bn) if b[n][0]!=b[n][1]}))
report=dict(base=base,scope='current staged and working source against recovery HEAD, including incoming allocator fix',reports=[str(p) for p in xmls],rows=rows,totals={k:sum(row[k] for row in rows) for k in ['instrumented','covered','covered_branches','total_branches']},glsl_instrumented=False)
(root/'design-a-changed-coverage.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
