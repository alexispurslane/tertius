#!/bin/bash
set -e
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
finish() { code=$?; printf "%s\n" "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-final-film-stage.exit'; }
trap finish EXIT
nix develop --command bash tools/cleanup.sh src/Tertius.Rendering/Frame/HistoryInstrumentation.cs src/Tertius.Rendering/Frame/ScreenTraceImages.cs src/Tertius.Rendering/Frame/SignalScratch.cs src/Tertius.Rendering/Frame/TemporalSignal.cs src/Tertius.Rendering/Passes/CompositePass.cs src/Tertius.Rendering/Vulkan/DeviceAllocator.cs tests/Tertius.Rendering.Tests/AccumulatorCutExposureTests.cs tests/Tertius.Rendering.Tests/AccumulatorRenderTests.cs tests/Tertius.Rendering.Tests/AccumulatorSceneRadianceTests.cs tests/Tertius.Rendering.Tests/AmbientCutSourceTests.cs tests/Tertius.Rendering.Tests/AmbientReflectionSourceTests.cs tests/Tertius.Rendering.Tests/DeviceAllocatorTests.cs tests/Tertius.Rendering.Tests/GlossyImageMemoryTests.cs tests/Tertius.Rendering.Tests/GlossySceneRadianceTests.cs tests/Tertius.Rendering.Tests/ReflectionSharingTests.cs tests/Tertius.Rendering.Tests/SamplePass.cs tests/Tertius.Rendering.Tests/ScreenTraceHardeningTests.cs tests/Tertius.Rendering.Tests/ScreenTraceRenderTests.cs > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-cleanup.log' 2>&1
python3 - <<'PY2'
import json,hashlib,pathlib
r=pathlib.Path('/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence')
h=json.loads((r/"design-a-hardened-source-sha256.json").read_text())
bad=[p for p,v in h.items() if hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=v]
(r/"design-a-cleanup-verification.json").write_text(json.dumps({"changed":bad},indent=2)+"\n")
if bad:raise SystemExit("Cleanup changed frozen inputs; inspect before further evidence: "+str(bad))
PY2
bash '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-captures.sh'
python3 '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-capture-analysis.py' > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-capture-analysis.log' 2>&1
