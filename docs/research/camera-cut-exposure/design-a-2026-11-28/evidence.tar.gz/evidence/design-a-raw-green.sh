#!/bin/bash
cd /Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236
nix develop --command tests/Tertius.Rendering.Tests/bin/Checked/net11.0/Tertius.Rendering.Tests -method '*TheFirstGlossyDestinationMatchesItsIndependentControlFromBothExposureEndpoints' -showLiveOutput -reporter verbose -noColor > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-raw-green.log' 2>&1
code=$?
printf '%s\n' "$code" > '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/design-a-raw-green.exit'
exit "$code"
