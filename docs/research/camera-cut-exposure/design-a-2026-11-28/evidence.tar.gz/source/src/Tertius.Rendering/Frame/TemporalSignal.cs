using Silk.NET.Vulkan;

namespace Tertius.Rendering;

/// <summary>
/// The history of one signal: demodulated light accumulated at each render pixel, in scene units for glossy reflections
/// and bounded pre-exposed units for diffuse signals
/// (https://github.com/alexispurslane/tertius/wiki/temporal-renderer, section 8, "The accumulator"). Its producer writes the sample of each part in each
/// frame. <see cref="Accumulate"/> then reprojects the last frame's history through the surface test, rescales it by the
/// exposure ratio for diffuse signals, blends the sample in, fixes short histories from their neighbors and clamps the slow history into the
/// fast history's box. A pixel whose sample is not finite keeps its history, and one without a history takes the
/// environment's closed form. In a reset frame, the surface test fails every tap, so every history starts again.
/// </summary>
/// <remarks>
/// <para>
/// The renderer accumulates the screen tracer's glossy reflections. Tests also supply synthetic signals.
/// Each part owns a sample and two fast histories. The slow history stores its length in alpha, and the fast specular
/// history stores the hit distance there. Every specular mode uses 32-bit floats for light. The precise mode also
/// records the age of each sample for the spatial dispatch.
/// </para>
/// <para>Invariants, checked by <see cref="AssertInvariants"/>:</para>
/// <list type="bullet">
/// <item>Every image of every part has the size of the targets that the signal binds.</item>
/// <item>The signal sets hold one set per part and parity.</item>
/// <item>The parameter set has a cap and a fast cap of at least 1.</item>
/// </list>
/// </remarks>
internal sealed unsafe class TemporalSignal : IDisposable
{
    /// <summary>The diffuse sample and history format, also used by geometric reflection guides.</summary>
    public const Format SignalFormat = Format.R16G16B16A16Sfloat;

    /// <summary>Linear scene radiance in glossy samples and both glossy histories, in every history mode.</summary>
    public const Format SceneSignalFormat = Format.R32G32B32A32Sfloat;

    private Format LightFormat => Parameters.Light == SignalLight.Specular ? SceneSignalFormat : SignalFormat;

    /// <summary>
    /// The format of a sample's age beside a precise specular history (sample_age.glsl): in <see cref="LightCodeMask"/> the
    /// youngest light code of the sample's rays, 0 for no light age, else the light age in frames plus 1, and the
    /// <see cref="SampleMotionBit"/>.
    /// </summary>
    public const Format SampleAgeFormat = Format.R16Uint;

    /// <summary>The bit of a sample age that says that the sample saw motion (sample_age.glsl, SampleMotionBit).</summary>
    public const ushort SampleMotionBit = 0x8000;

    /// <summary>The bits of a sample age that hold the youngest light code (sample_age.glsl, LightCodeMask).</summary>
    public const ushort LightCodeMask = 0x7FFF;

    /// <summary>
    /// The format of the diagnostic of uncovered surfaces under <see cref="HistoryInstrumentation.LightAgeDiagnostic"/>: r the
    /// fewest frames seen among the never-changed surfaces that the specular sample's rays hit, or −1 for none, which the
    /// resolve writes; g the slow history's length just before its blend, or −1 without a sample; b 1 where the sample
    /// holds at least a quarter of the slow history's luminance, else 0, an observation that no rule uses since ter-g3tk;
    /// a the length just before the blend again, where it held the length before the light-age cut until that cut went
    /// (https://github.com/alexispurslane/tertius/wiki/bounce-light-confidence, section 4). The temporal dispatch writes g, b and a.
    /// </summary>
    public const Format UncoveredDiagnosticFormat = Format.R32G32B32A32Sfloat;

    /// <summary>
    /// The width and the height of a workgroup of both dispatches, the shaders' local size, and so of a block, whose
    /// evidence the spatial dispatch shares among its pixels.
    /// </summary>
    private const uint GroupSize = 8;

    private readonly VulkanDevice device;
    private readonly DeviceAllocator allocator;
    private readonly DescriptorLayouts layouts;
    private readonly RenderTargets targets;
    private readonly SurfaceHistory surfaces;
    private readonly SignalScratch scratch;
    private readonly Pipeline temporal;
    private readonly Pipeline spatial;
    private readonly bool reflectionDistanceHistory;
    private readonly PartImages[] parts;

    /// <summary>The signal sets, [part, parity].</summary>
    private readonly DescriptorSet[,] sets;

    /// <param name="targets">The render targets, whose size the images take, and whose motion target the sets bind.</param>
    /// <param name="surfaces">The surface history, whose test image and last images the sets bind.</param>
    /// <param name="scratch">The scratch images, which every signal shares.</param>
    /// <param name="name">The signal's name in the images' names and the passes' names, such as "indirect diffuse".</param>
    /// <param name="parts">The signal's parts, such as 2 for a diffuse and a specular part.</param>
    /// <exception cref="NotSupportedException">The format is not a color attachment and a storage image on the device.</exception>
    public TemporalSignal(
        VulkanDevice device,
        DeviceAllocator allocator,
        DescriptorLayouts layouts,
        ShaderLibrary shaders,
        RenderTargets targets,
        SurfaceHistory surfaces,
        SignalScratch scratch,
        SignalParameters parameters,
        string name,
        int parts
    )
    {
        ArgumentOutOfRangeException.ThrowIfLessThan(parts, 1);
        ArgumentOutOfRangeException.ThrowIfGreaterThan(parts, MostParts);
        if (!ConfidenceFitsLight(parameters))
            throw new ArgumentException(
                "The widened box keeps the deviation of the diffuse light in its fast alpha, where the reflections keep the hit distance.",
                nameof(parameters)
            );
        CheckDevice(device, parameters.Light == SignalLight.Specular ? SceneSignalFormat : SignalFormat);

        this.device = device;
        this.allocator = allocator;
        this.layouts = layouts;
        this.targets = targets;
        this.surfaces = surfaces;
        this.scratch = scratch;

        Name = name;
        HistoryMode = parameters.Light == SignalLight.Specular ? scratch.HistoryMode : SpecularHistoryMode.Original;
        Instrumentation =
            parameters.Light == SignalLight.Specular ? scratch.Instrumentation : HistoryInstrumentation.None;

        this.parts = new PartImages[parts];
        sets = new DescriptorSet[parts, 2];
        for (int part = 0; part < parts; part++)
        for (int parity = 0; parity < 2; parity++)
            sets[part, parity] = layouts.AllocateSignalSet();

        bool limitIncoming =
            Environment.GetEnvironmentVariable("TERTIUS_INDIRECT_LIGHT_PROTOTYPE") == "1"
            && Environment.GetEnvironmentVariable("TERTIUS_INDIRECT_LIGHT_NEIGHBOR_CAP") != "0";
        Parameters = parameters with
        {
            Confidence = scratch.HistoryMode.KeepsLightAge ? parameters.Confidence : new NarrowBox(),
        };
        reflectionDistanceHistory =
            parameters.Light == SignalLight.Specular
            && Environment.GetEnvironmentVariable("TERTIUS_REFLECTION_SHARING") == "1";
        temporal = CreatePipeline(shaders, "temporal", limitIncoming);
        spatial = CreatePipeline(shaders, "spatial");
        Create();
    }

    /// <summary>
    /// Whether the confidence rules of <paramref name="parameters"/> keep their deviation where its signal's shaders look
    /// for it: only the diffuse light's fast history keeps a deviation in its alpha.
    /// </summary>
    private static bool ConfidenceFitsLight(SignalParameters parameters) =>
        parameters.Confidence switch
        {
            WidenedBox => parameters.Light == SignalLight.Diffuse,
            NarrowBox => true,
            null => throw new ArgumentException("A signal's parameters need confidence rules.", nameof(parameters)),
        };

    /// <summary>The pipeline of the dispatch of <paramref name="kind"/>, "temporal" or "spatial": accumulate_kind.comp.</summary>
    private Pipeline CreatePipeline(ShaderLibrary shaders, string kind, bool limitIncoming = false) =>
        new ComputePipelineDesc
        {
            Name = $"accumulate {Name} {kind}",
            Shader = HistoryShader($"accumulate_{kind}.comp"),
            Layout = layouts.AccumulateLayout,
            Constants =
                limitIncoming || reflectionDistanceHistory
                    ? new ShaderConstants(EnvironmentMap: false)
                    {
                        NeighborLimitPrototype = limitIncoming,
                        ReflectionSharingPrototype = reflectionDistanceHistory,
                    }
                    : null,
        }.Create(device, shaders);

    /// <summary>The signal's name in the images' names and the passes' names, such as "indirect diffuse".</summary>
    public string Name { get; }

    /// <summary>The signal's parts.</summary>
    public int Parts => parts.Length;

    /// <summary>The signal's parameter set.</summary>
    public SignalParameters Parameters { get; }

    /// <summary>
    /// The slow history's storage: the specular history's mode, or original storage for other signals. Whether the signal's
    /// samples have a light age is <see cref="KeepsLightAge"/>.
    /// </summary>
    public SpecularHistoryMode HistoryMode { get; }

    /// <summary>The instrumentation of the specular history, or none for other signals.</summary>
    public HistoryInstrumentation Instrumentation { get; }

    /// <summary>
    /// Whether the signal's samples have a light age (<see cref="SampleAge(int)"/>), the evidence of a light change by which
    /// its history is cut: every signal beside a precise specular history, whose screen tracer records the light-change age
    /// of each pixel.
    /// </summary>
    public bool KeepsLightAge => scratch.HistoryMode.KeepsLightAge;

    /// <summary>
    /// The shader variant whose declared slow-history format matches this signal's storage (<see cref="HistoryShader(string,
    /// SpecularHistoryMode, HistoryInstrumentation)"/>), and which reads the light age where the signal keeps it
    /// (<see cref="LightAgeShader(string)"/>).
    /// </summary>
    public string HistoryShader(string shader)
    {
        if (
            Parameters.Light == SignalLight.Specular
            && HistoryMode == SpecularHistoryMode.Original
            && ShaderVariant.SceneSignal.Shaders.Contains(shader)
        )
            return ShaderVariant.Of(shader, ShaderVariant.SceneSignal.Suffix);
        if (HistoryMode == SpecularHistoryMode.Original && KeepsLightAge)
            return LightAgeShader(shader);
        return HistoryShader(shader, HistoryMode, Instrumentation);
    }

    /// <summary>
    /// The variant of <paramref name="shader"/> for a half-precision history whose samples have a light age: the
    /// light-age variant for the shaders that it holds, the spatial dispatch alone, and the shader itself otherwise.
    /// </summary>
    internal static string LightAgeShader(string shader) =>
        ShaderVariant.LightAge.Shaders.Contains(shader)
            ? ShaderVariant.Of(shader, ShaderVariant.LightAge.Suffix)
            : shader;

    /// <summary>
    /// The variant of <paramref name="shader"/> for a history of <paramref name="mode"/>. The precise variants keep the
    /// light-change age. Under an instrumentation, the shaders of its variant take that variant, which also writes its
    /// image (<see cref="HistoryInstrumentationSelection"/>).
    /// </summary>
    internal static string HistoryShader(
        string shader,
        SpecularHistoryMode mode,
        HistoryInstrumentation instrumentation
    )
    {
        if (mode == SpecularHistoryMode.Original)
            return shader;
        string suffix =
            instrumentation.Variant is { } variant && variant.Shaders.Contains(shader)
                ? variant.Suffix
                : ShaderVariant.PreciseSuffix;
        return ShaderVariant.Of(shader, suffix);
    }

    /// <summary>The most parts of a signal: the descriptor pool holds the sets of a test's signal of two parts.</summary>
    public const int MostParts = 2;

    /// <summary>The sample of <paramref name="part"/>, which the producer writes in each frame: rgb the light, a 1.</summary>
    public GpuImage Sample(int part) => parts[part].Sample;

    /// <summary>
    /// The slow history of <paramref name="part"/> after the last accumulation: rgb the light, a the length.
    /// </summary>
    public GpuImage Slow(int part) => parts[part].Slow;

    /// <summary>
    /// The fast history of <paramref name="part"/> that the frame of <paramref name="parity"/> writes: rgb the light, a the
    /// specular signal's hit distance or the diffuse signal's deviation of its samples' luminance.
    /// </summary>
    public GpuImage Fast(int part, int parity) => parts[part].Fast(parity);

    public GpuImage ReflectionGuide(int part) =>
        reflectionDistanceHistory ? parts[part].ReflectionGuide : scratch.Part(part);

    /// <summary>
    /// The light age of the sample of <paramref name="part"/>, which the resolve writes beside a precise specular history
    /// (<see cref="SampleAgeFormat"/>, <see cref="KeepsLightAge"/>), or null without it.
    /// </summary>
    public GpuImage? SampleAge(int part) => parts[part].SampleAge;

    /// <summary>
    /// The diagnostic of uncovered surfaces of <paramref name="part"/> under <see cref="HistoryInstrumentation.LightAgeDiagnostic"/>
    /// (<see cref="UncoveredDiagnosticFormat"/>), or null without it. Only the capture tool and the tests read it.
    /// </summary>
    public GpuImage? UncoveredDiagnostic(int part) => parts[part].Ages is [_, var diagnostic] ? diagnostic : null;

    /// <summary>
    /// The layers of the accumulation trace (<see cref="AccumulationTrace(int)"/>), each RGBA32F at the targets' size. The
    /// temporal dispatch writes layers 0 to 3 and 8 and the spatial dispatch layers 4 to 7, for every pixel, 0 for sky. The
    /// spatial dispatch stores only values that it computes anyway, because an arithmetic of the trace's own changed the
    /// driver's rounding of the slow history:
    /// <list type="number">
    /// <item>The length that the last draw accepted at the pixel's own texel, the length after the reprojection and
    /// before the blend, the sum of the taps' weights, and flags: bits 0 to 3 the taps that hold weight, 4 the reflected
    /// place won, 5 it was tried, 6 the surface place holds a history, 7 the reflected place does, 8 the pixel has a
    /// sample, 9 it shows a surface, 10 it read at its pixel place (the pixel history rule, screen.glsl), 11 its tried
    /// reflected place is that place's pixel place.</item>
    /// <item>The four taps' bilinear weights times their pass bits, in the order of the surface test.</item>
    /// <item>Where the place that won lies relative to the pixel, in texels of the last image, so that tap 0 is its
    /// floor; the sample's hit distance, 0 for a miss; the sample's luminance, 0 without one.</item>
    /// <item>The least and the most length of the taps that hold weight, and the luminance of the reprojected fast and
    /// slow histories before the exposure ratio, 0 without a history.</item>
    /// <item>The length before and after the anti-lag.</item>
    /// <item>The slow history after the fix and before the clamp, and 1 where the clamp ran, else 0.</item>
    /// <item>The box's mean, the mean of the 3 × 3 fast histories, and the lag, 0 without the clamp.</item>
    /// <item>The fast histories' standard deviation, 0 without the clamp.</item>
    /// <item>The weight of the taps that pass the surface test at the pixel place and at the sample place, then of those
    /// that pass the specular test at each (ticket tiunr-wk29). The pixel place is the pixel moved by the scene's motion
    /// alone; under the control nothing reads it, but the trace weighs it.</item>
    /// </list>
    /// </summary>
    public const int TraceLayers = 9;

    /// <summary>The format of each layer of the accumulation trace.</summary>
    public const Format TraceFormat = Format.R32G32B32A32Sfloat;

    /// <summary>
    /// The accumulation trace of <paramref name="part"/> under <see cref="HistoryInstrumentation.ControlTrace"/>
    /// (<see cref="TraceLayers"/>), or null without it. Only the capture tool and the tests read it.
    /// </summary>
    public GpuImage? AccumulationTrace(int part) => parts[part].Traces is [var trace] ? trace : null;

    /// <summary>
    /// The images of <paramref name="part"/> that the screen tracer binds in a frame of <paramref name="parity"/>: the
    /// sample, which its resolve writes, the fast history that the last drawn frame wrote, which its hits read, and the
    /// slow history, whose length its ray plan reads before this frame's accumulation. Each pass binds one set of its own,
    /// because a pipeline gets at most four sets on every driver, so the tracer's set binds these images.
    /// </summary>
    public (GpuImage Sample, GpuImage LastFast, GpuImage Slow) HitImages(int part, int parity) =>
        (parts[part].Sample, parts[part].LastFast(parity), parts[part].Slow);

    /// <summary>
    /// Records both dispatches of each part: the temporal dispatch reprojects and blends into the scratch image and this
    /// frame's fast history, and the spatial dispatch fixes, clamps and writes the slow history. Its reads of the surface
    /// test's outputs follow the surface test pass, and its read of each sample follows the producer.
    /// </summary>
    public void Accumulate(FrameContext context)
    {
        Contract.Requires(context.Targets == targets && FitsTargets());
        int parity = context.History.Parity;
        BarrierBatch barriers = context.Barriers;
        barriers.Image(targets.Distance, ImageUse.SampledCompute);
        barriers.Image(targets.Normal, ImageUse.SampledCompute);
        barriers.Image(targets.Shading, ImageUse.SampledCompute);
        barriers.Image(surfaces.Test, ImageUse.StorageCompute);
        barriers.Image(targets.Motion, ImageUse.StorageCompute);

        // The closed form's material, and the last frame's surfaces of the reflected point's surface test.
        barriers.Image(targets.BaseColor, ImageUse.SampledCompute);
        barriers.Image(targets.Specular, ImageUse.SampledCompute);
        barriers.Image(targets.Emissive, ImageUse.SampledCompute);
        barriers.Image(surfaces.Last(parity), ImageUse.SampledCompute);
        barriers.Image(surfaces.LastDepth(parity), ImageUse.SampledCompute);
        barriers.Buffer(context.Exposure.Buffer, BufferUse.ComputeRead);
        for (int part = 0; part < parts.Length; part++)
        {
            BeforeTemporal(barriers: barriers, part: part, parity: parity);
            Dispatch(context: context, pipeline: temporal, set: sets[part, parity]);
            BeforeSpatial(barriers: barriers, part: part, parity: parity);
            Dispatch(context: context, pipeline: spatial, set: sets[part, parity]);
        }
    }

    /// <summary>The barriers of <paramref name="part"/>'s images before its temporal dispatch.</summary>
    private void BeforeTemporal(BarrierBatch barriers, int part, int parity)
    {
        PartImages images = parts[part];
        if (!reflectionDistanceHistory && Parameters.Light == SignalLight.Specular)
            barriers.Image(scratch.Part(part), ImageUse.StorageCompute);
        barriers.Image(images.Sample, ImageUse.StorageCompute);
        foreach (GpuImage age in images.Ages)
            barriers.Image(age, ImageUse.StorageCompute);
        foreach (GpuImage trace in images.Traces)
            barriers.Image(trace, ImageUse.StorageCompute);
        barriers.Image(images.Slow, ImageUse.StorageCompute);
        barriers.Image(images.LastFast(parity), ImageUse.StorageCompute);
        barriers.Image(images.Fast(parity), ImageUse.StorageCompute, discard: true);
        if (reflectionDistanceHistory)
        {
            barriers.Image(images.ReflectionGuide, ImageUse.StorageCompute);
            barriers.Image(images.ReflectionGuideScratch, ImageUse.StorageCompute, discard: true);
        }
        // After the last signal's spatial dispatch, which read it.
        barriers.Image(scratch.Part(part, Parameters.Light), ImageUse.StorageCompute, discard: true);
    }

    /// <summary>
    /// The barriers of <paramref name="part"/>'s images before its spatial dispatch, which reads the neighbors' results of
    /// the temporal one. The sample age needs none: only the spatial dispatch reads it, and nothing writes it here.
    /// </summary>
    private void BeforeSpatial(BarrierBatch barriers, int part, int parity)
    {
        PartImages images = parts[part];
        barriers.Image(scratch.Part(part, Parameters.Light), ImageUse.StorageCompute);
        if (!reflectionDistanceHistory && Parameters.Light == SignalLight.Specular)
            barriers.Image(scratch.Part(part), ImageUse.StorageCompute);
        barriers.Image(images.Fast(parity), ImageUse.StorageCompute);
        barriers.Image(images.Slow, ImageUse.StorageCompute);
        foreach (GpuImage trace in images.Traces)
            barriers.Image(trace, ImageUse.StorageCompute);
        if (reflectionDistanceHistory)
        {
            barriers.Image(images.ReflectionGuideScratch, ImageUse.StorageCompute);
            barriers.Image(images.ReflectionGuide, ImageUse.StorageCompute, discard: true);
        }
    }

    /// <summary>
    /// Recreates the images at the size of the targets that the signal binds, and rewrites every set. The device must be
    /// idle, and the surface history resized first, because the sets point at its test image. A new size resets every
    /// history (<see cref="FrameHistory.Begin"/>), so the images' contents need not survive.
    /// </summary>
    public void Resize()
    {
        Contract.Requires(SameExtent(surfaces.Test.Extent, targets.Extent));
        Contract.Requires(SameExtent(scratch.Part(0, Parameters.Light).Extent, targets.Extent));
        DestroyImages();
        Create();
        Contract.Ensures(FitsTargets());
    }

    /// <summary>Checks the invariants in the class remarks.</summary>
    internal void AssertInvariants()
    {
        Contract.Invariant(FitsTargets());
        Contract.Invariant(sets.GetLength(0) == parts.Length && sets.GetLength(1) == 2);
        Contract.Invariant(Parameters.Cap >= 1 && Parameters.FastCap >= 1);
    }

    /// <summary>Whether every image of every part has the targets' size. It allocates nothing, so a frame can check it.</summary>
    private bool FitsTargets()
    {
        foreach (PartImages images in parts)
            if (!images.Fit(targets.Extent))
                return false;
        return true;
    }

    private static bool SameExtent(Extent2D a, Extent2D b) => a.Width == b.Width && a.Height == b.Height;

    /// <summary>The blocks of 8 × 8 pixels that cover <paramref name="extent"/>: one workgroup of each dispatch per block.</summary>
    private static Extent2D BlocksOf(Extent2D extent) =>
        new((extent.Width + GroupSize - 1) / GroupSize, (extent.Height + GroupSize - 1) / GroupSize);

    private void Dispatch(FrameContext context, Pipeline pipeline, DescriptorSet set)
    {
        context.BeginComputePass(pipeline: pipeline, layout: layouts.AccumulateLayout, passSet: set);
        var push = AccumulatePushConstants.Of(Parameters, context.History.Reset, context.History.DrawIndex);
        if (HistoryMode == SpecularHistoryMode.PreciseUncapped)
        {
            push.Cap = float.PositiveInfinity;
            push.SmoothCap = float.PositiveInfinity;
        }
        context.Vk.CmdPushConstants(
            commandBuffer: context.CommandBuffer,
            layout: layouts.AccumulateLayout,
            stageFlags: ShaderStageFlags.ComputeBit,
            offset: 0,
            size: (uint)sizeof(AccumulatePushConstants),
            pValues: &push
        );
        Extent2D groups = BlocksOf(context.Extent);
        context.Vk.CmdDispatch(
            commandBuffer: context.CommandBuffer,
            groupCountX: groups.Width,
            groupCountY: groups.Height,
            groupCountZ: 1
        );
    }

    private void Create()
    {
        Extent2D extent = targets.Extent;
        for (int part = 0; part < parts.Length; part++)
        {
            parts[part] = new PartImages(
                Sample: CreateImage(
                    extent,
                    $"{Name} sample {part}",
                    ImageUsageFlags.ColorAttachmentBit | ImageUsageFlags.TransferDstBit
                ),
                Slow: CreateImage(
                    extent: extent,
                    imageName: $"{Name} slow history {part}",
                    extraUsage: 0,
                    format: LightFormat
                ),
                Fasts:
                [
                    CreateImage(extent, $"{Name} fast history {part}.0", 0),
                    CreateImage(extent, $"{Name} fast history {part}.1", 0),
                ],
                Guides: reflectionDistanceHistory
                    ?
                    [
                        CreateImage(
                            extent: extent,
                            imageName: $"{Name} distance guide {part}",
                            extraUsage: 0,
                            format: SignalFormat
                        ),
                        CreateImage(
                            extent: extent,
                            imageName: $"{Name} distance guide scratch {part}",
                            extraUsage: 0,
                            format: SignalFormat
                        ),
                    ]
                    : [],
                Ages: CreateAges(extent, part),
                Traces: Instrumentation == HistoryInstrumentation.ControlTrace ? [CreateTrace(extent, part)] : []
            );
            for (int parity = 0; parity < 2; parity++)
                WriteSignalSet(set: sets[part, parity], images: parts[part], part: part, parity: parity);
        }
    }

    private void WriteSignalSet(DescriptorSet set, PartImages images, int part, int parity)
    {
        layouts.WriteStorageImage(set: set, binding: 0, image: images.Sample);
        layouts.WriteStorageImage(set: set, binding: 1, image: images.Slow);
        layouts.WriteStorageImage(set: set, binding: 2, image: images.LastFast(parity));
        layouts.WriteStorageImage(set: set, binding: 3, image: images.Fast(parity));
        layouts.WriteStorageImage(set: set, binding: 4, image: scratch.Part(part, Parameters.Light));
        layouts.WriteStorageImage(set: set, binding: 5, image: surfaces.Test);
        layouts.WriteStorageImage(set: set, binding: 6, image: targets.Motion);
        layouts.WriteImage(set: set, binding: 7, arrayElement: 0, image: surfaces.Last(parity));
        layouts.WriteImage(set: set, binding: 8, arrayElement: 0, image: surfaces.LastDepth(parity));
        layouts.WriteStorageImage(
            set: set,
            binding: 9,
            image: reflectionDistanceHistory ? images.ReflectionGuide : scratch.Part(part)
        );
        layouts.WriteStorageImage(
            set: set,
            binding: 10,
            image: reflectionDistanceHistory ? images.ReflectionGuideScratch : scratch.Part(part)
        );
        // The sample age, which the temporal dispatch of both signals reads.
        if (images.SampleAge is { } age)
            layouts.WriteStorageImage(set: set, binding: 11, image: age);
        // The diagnostic of uncovered surfaces, which only the specular signal's temporal dispatch writes.
        if (scratch.Instrumentation == HistoryInstrumentation.LightAgeDiagnostic)
            layouts.WriteStorageImage(
                set: set,
                binding: 12,
                image: images.Ages is [_, var diagnostic] ? diagnostic : images.Sample
            );
        // The accumulation trace, which only the specular signal's dispatches write: another signal binds its sample.
        if (scratch.Instrumentation == HistoryInstrumentation.ControlTrace)
            layouts.WriteStorageImage(
                set: set,
                binding: 12,
                image: images.Traces is [var trace] ? trace : images.Sample
            );
    }

    /// <summary>
    /// The light-age images of <paramref name="part"/>: none without the light age, else the sample age, and under the
    /// diagnostic the diagnostic of uncovered surfaces after it.
    /// </summary>
    private GpuImage[] CreateAges(Extent2D extent, int part) =>
        (KeepsLightAge, Instrumentation) switch
        {
            (false, _) => [],
            (true, not HistoryInstrumentation.LightAgeDiagnostic) => [CreateSampleAge(extent, part)],
            (true, HistoryInstrumentation.LightAgeDiagnostic) =>
            [
                CreateSampleAge(extent, part),
                CreateImage(
                    extent: extent,
                    imageName: $"{Name} uncovered diagnostic {part}",
                    extraUsage: 0,
                    format: UncoveredDiagnosticFormat
                ),
            ],
        };

    /// <summary>The sample age of <paramref name="part"/>, which its producer writes as it writes the sample.</summary>
    private GpuImage CreateSampleAge(Extent2D extent, int part) =>
        CreateImage(
            extent: extent,
            imageName: $"{Name} sample age {part}",
            extraUsage: ImageUsageFlags.TransferDstBit,
            format: SampleAgeFormat
        );

    /// <summary>The accumulation trace of <paramref name="part"/> (<see cref="TraceLayers"/>).</summary>
    private GpuImage CreateTrace(Extent2D extent, int part) =>
        GpuImage.Create(
            device: device,
            allocator: allocator,
            extent: extent,
            format: TraceFormat,
            usage: ImageUsageFlags.StorageBit | ImageUsageFlags.TransferSrcBit,
            mipLevels: 1,
            name: $"{Name} accumulation trace {part}",
            arrayLayers: TraceLayers
        );

    /// <summary>
    /// An image of the signal at <paramref name="extent"/>: a storage image, which the read hooks copy out, plus
    /// <paramref name="extraUsage"/>.
    /// </summary>
    private GpuImage CreateImage(Extent2D extent, string imageName, ImageUsageFlags extraUsage) =>
        CreateImage(extent: extent, imageName: imageName, extraUsage: extraUsage, format: LightFormat);

    private GpuImage CreateImage(Extent2D extent, string imageName, ImageUsageFlags extraUsage, Format format) =>
        GpuImage.Create(
            device: device,
            allocator: allocator,
            extent: extent,
            format: format,
            usage: ImageUsageFlags.StorageBit | ImageUsageFlags.TransferSrcBit | extraUsage,
            mipLevels: 1,
            name: imageName
        );

    private static void CheckDevice(VulkanDevice device, Format format)
    {
        const FormatFeatureFlags needed = FormatFeatureFlags.StorageImageBit | FormatFeatureFlags.ColorAttachmentBit;
        if ((device.FormatProperties(format).OptimalTilingFeatures & needed) != needed)
            throw new NotSupportedException(
                $"{format} cannot be a color attachment and a storage image on {device.DeviceName}."
            );
    }

    private void DestroyImages()
    {
        foreach (PartImages images in parts)
        foreach (GpuImage image in images.All)
            image.Dispose();
    }

    // The pool of the layouts frees the sets.
    public void Dispose()
    {
        DestroyImages();
        device.Vk.DestroyPipeline(device.Device, temporal, null);
        device.Vk.DestroyPipeline(device.Device, spatial, null);
    }

    /// <summary>The images of one part.</summary>
    private sealed record PartImages(
        GpuImage Sample,
        GpuImage Slow,
        GpuImage[] Fasts,
        GpuImage[] Guides,
        GpuImage[] Ages,
        GpuImage[] Traces
    )
    {
        /// <summary>The fast history that the frame of <paramref name="parity"/> writes.</summary>
        public GpuImage Fast(int parity) => Fasts[parity];

        /// <summary>The fast history that the last drawn frame wrote.</summary>
        public GpuImage LastFast(int parity) => Fasts[1 - parity];

        public GpuImage ReflectionGuide => Guides.Length == 0 ? Sample : Guides[0];

        public GpuImage ReflectionGuideScratch => Guides[1];

        public GpuImage? SampleAge => Ages is [var age, ..] ? age : null;

        public IEnumerable<GpuImage> All => [Sample, Slow, .. Fasts, .. Guides, .. Ages, .. Traces];

        /// <summary>Whether every image has <paramref name="extent"/>.</summary>
        public bool Fit(Extent2D extent) =>
            SameExtent(Sample.Extent, extent)
            && SameExtent(Slow.Extent, extent)
            && AllFit(Fasts, extent)
            && AllFit(Guides, extent)
            && AllFit(Ages, extent)
            && AllFit(Traces, extent);

        /// <summary>Whether every image of <paramref name="images"/> has <paramref name="extent"/>.</summary>
        private static bool AllFit(GpuImage[] images, Extent2D extent)
        {
            foreach (GpuImage image in images)
                if (!SameExtent(image.Extent, extent))
                    return false;
            return true;
        }
    }
}

/// <summary>
/// The accumulation of a signal as a pass of the frame graph, named "accumulate" and the signal's name: after its
/// producer, whose samples it reads.
/// </summary>
internal sealed class AccumulatePass(TemporalSignal signal) : RenderPass
{
    // Made once, because the timer reads the name in every frame, which allocates nothing.
    private readonly string name = $"accumulate {signal.Name}";

    public override string Name => name;

    public override void Record(FrameContext context) => signal.Accumulate(context);
}
