// Glossy reflection sampling, depth traversal and ray records shared by the screen-trace passes.
#ifndef TERTIUS_SCREEN_TRACE_GLSL
#define TERTIUS_SCREEN_TRACE_GLSL

#extension GL_GOOGLE_include_directive : require
#extension GL_EXT_samplerless_texture_functions : require
#include "frame.glsl"
#include "gbuffer_surface.glsl"
#include "temporal.glsl"
#include "signals.glsl"
#include "screen_walk.glsl"
#include "own_rays.glsl"
#include "motion.glsl"
#include "sample_age.glsl"
#include "meter.glsl"

layout(set = 3, binding = 0) uniform texture2D depthFinest;                    // RG32F: each pixel's center w and back w
layout(set = 3, binding = 1) uniform texture2D depthPyramid;                   // RG32F, mip m = level m + 1
layout(set = 3, binding = 2, rgba32f) uniform readonly image2D directDiffuseLight;   // actual scene radiance
layout(set = 3, binding = 3, rgba32f) uniform readonly image2D directSpecularLight;
layout(set = 3, binding = 4, r16ui) uniform readonly uimage2D surfaceTest;      // the pass bits (signals.glsl)
layout(set = 3, binding = 5, rgba16f) uniform readonly image2D motionTarget;   // the G-buffer's motion target
// The reprojected reflection from the previous frame.
layout(set = 3, binding = 6, rgba32f) uniform readonly image2D lastFastSpecular;
#define TERTIUS_SCENE_SPECULAR
#include "specular_history.glsl"
layout(set = 3, binding = 7, SPECULAR_HISTORY_FORMAT) uniform readonly image2D slowSpecular;
layout(set = 3, binding = 8, r8ui) uniform uimage2D rayPlan;                  // the plan's bits (PlanOwnRay)
// The records of the rays, one record per location: rgb linear scene radiance in W/(m² sr), a its hit distance in
// m, 0 for a miss; and x, y the direction's octahedral code in 16-bit units, z the half bits of log2 of its density per
// steradian, w RayTraced, with a precise specular history also the hit's light code and moved mark (recordOf). A block's
// record at the block, an own ray's at its pixel.
layout(set = 3, binding = 9, rgba32f) uniform image2D blockLight;
layout(set = 3, binding = 10, rgba16ui) uniform uimage2D blockRay;
layout(set = 3, binding = 11, rgba32f) uniform image2D ownLight;
layout(set = 3, binding = 12, rgba16ui) uniform uimage2D ownRay;
// Reflection radiance in RGB and hit distance in alpha.
layout(set = 3, binding = 13, rgba32f) uniform writeonly image2D specularSample;
OWN_RAY_LIST(3, 14, reflectionOwnRays);
// The light pyramid (ARCHITECTURE.md, "Guided rays", light_pyramid.glsl): each pixel's guide light, and the sums
// of levels 1 to L, mip m level m + 1, whose padding holds no light. Bindings 15 to 19 are the light age's.
layout(set = 3, binding = 20) uniform texture2D lightFinest;    // R32F
layout(set = 3, binding = 21) uniform texture2D lightLevels;    // R32F
// The hit light (ticket ter-67y3, ScreenTraceImages.HitLight), one record per location: rgb the light that
// leaves each pixel that a walk can hit toward a ray of the kind (leavingLightOf), and a the pixel's moved mark, 1 where
// its surface moved since the last draw (movedSurfaceAt), else 0. The plan writes it, and a hit reads both.
layout(set = 3, binding = 22, rgba32f) uniform image2D hitLight;
// The reflection share of each tile of TileBlocks × TileBlocks blocks (ScreenTraceImages.ReflectionShare, GuidedShares):
// the share of the tile's reflection rays that take the guided draw, after the last drawn frame. The tracer reads it at a
// pixel's block (tileShareAt), and the share pass moves it after the resolve. It covers the tiles of the largest render
// size.
layout(set = 3, binding = 23, r32f) uniform image2D reflectionShare;
// The guide of each block's reflection ray (ScreenTraceImages.BlockGuide), which the block pass writes while the rays are
// guided: x its guided density along its direction, y and z its evidence for its tile's share (shareEvidenceOf), and w
// the share at which it was drawn. The resolve weighs the ray at each pixel of the block by that share's mixture.
layout(set = 3, binding = 24, rgba32f) uniform image2D blockGuide;
// ShaderConstants.LightVolumeOn, at ShaderConstants.LightVolumeOnId.
layout(constant_id = 12) const bool lightVolumeOn = false;
#define VOLUME_BINDING 25
#include "volume_receive.glsl"
// The blocks along each side of a tile of the reflection share (ScreenTraceImages.TileBlocks).
const int TileBlocks = 8;
#include "sent_light.glsl"

// A record's w: bit 0 whether its ray traced. A ray below its pixel's geometric plane, and a block that no pixel starts,
// trace nothing. With a precise specular history, bits 1 to 14 hold the hit's light code (RecordCodeBits) and bit 15 its
// moved mark (RecordMovedMark), so the rays take no new storage (https://github.com/alexispurslane/tertius/wiki/bounce-light-confidence, section 8.5).
const uint RayTraced = 1u;
const uint RecordCodeBits = 0x3FFFu;
const uint RecordMovedMark = 0x8000u;

#ifdef TERTIUS_PRECISE_SPECULAR_HISTORY
// The light-change age of a precise specular history (tickets tiunr-py6q and tiunr-7haj, ScreenTraceImages.LightAge): r
// the exact light at the pixel, g the frames since it last changed, or for a light that the record never saw change −(N + 1), where N counts the frames since the
// frame that first showed the pixel. The fraction of g holds a pending change (ticket tiunr-okzm, recordAgeOf). The plan
// writes this frame's record from the last frame's, and a hit reads this frame's record at its pixel.
layout(set = 3, binding = 15, rg32f) uniform readonly image2D lastLightAge;
layout(set = 3, binding = 16, rg32f) uniform image2D lightAge;
// The reflection sample's age (TemporalSignal.SampleAge), which the resolve writes: the youngest light code of their rays
// (ageCodeOf) and their motion bit (sample_age.glsl).
layout(set = 3, binding = 17, r16ui) uniform writeonly uimage2D specularSampleAge;
// FSR 3.1's transparency and composition mask (ScreenTraceImages.LightChangeMask), which the resolve writes from this
// frame's records (lightChangeMaskAt): where the direct light changed, FSR's history keeps to this frame's light (ticket
// t1-4hij).
layout(set = 3, binding = 18, r8) uniform writeonly image2D lightChangeMask;

// The age of a pixel whose light the record never saw change, in the frame that first shows it: no evidence. Each later
// frame that shows it unchanged lowers it by one, down to −(MostLightAge + 1).
const float NoLightAge = -1.0;

// The largest age that a record holds: a single float keeps it and its pending draws exactly (recordAgeOf).
const float MostLightAge = 32766.0;

// The largest age that a light code holds: the code, the age plus 1, fills the 14 bits of a ray record's w between
// RayTraced and the moved mark (recordOf). An older light codes as this age, which changes no cut while a history holds
// fewer frames (https://github.com/alexispurslane/tertius/wiki/bounce-light-confidence, section 8.5).
const float MostCodedAge = 16382.0;

// The draws in a row that a light must stay outside the range of the last exact light to count as a change
// (ARCHITECTURE.md, the light-change age, and t2-hvez).
const float LightChangeDraws = 4.0;

// The code of an age in a ray record and in the sample age: 0 for no evidence, else the age plus 1.
uint ageCodeOf(float age)
{
    return age < 0.0 ? 0u : uint(min(age, MostCodedAge)) + 1u;
}

// A record's g: the age, whose integer part it keeps, plus, away from 0, the draws that a pending change has stayed
// outside the range, in steps of 1 / LightChangeDraws. A single float holds both exactly: the age's magnitude stays below
// 2^15, so 8 bits of fraction remain, and LightChangeDraws is a power of 2.
float recordAgeOf(float age, float pendingDraws)
{
    float pending = pendingDraws / LightChangeDraws;
    return age < 0.0 ? age - pending : age + pending;
}

// The age of a record's g (recordAgeOf). A hit stores g as it is: ageCodeOf and rayFieldOf round toward 0 as this does.
float ageOfRecord(float g)
{
    return trunc(g);
}

// The draws of a record's pending change (recordAgeOf): 0 for none.
float pendingDrawsOfRecord(float g)
{
    return round(abs(g - trunc(g)) * LightChangeDraws);
}

// The frames after a change of the pixel's light in which FSR's history keeps to this frame's light.
const float LightChangeMaskFrames = 8.0;

// Whether a record's g shows its pixel's light changing (ticket t1-4hij): while a change is pending and for
// LightChangeMaskFrames frames after it counts.
bool changingLight(float g)
{
    bool recent = g >= 0.0 && ageOfRecord(g) < LightChangeMaskFrames;
    return recent || pendingDrawsOfRecord(g) > 0.0;
}

// Whether a change of the light covers an area at a pixel (https://github.com/alexispurslane/tertius/wiki/sub-pixel-strips, section 5.2): whether the
// opening of the changing records by a 3 × 3 block holds the pixel, that is whether some 3 × 3 block around it changes
// whole. `changing` holds changingLight of the 5 × 5 records around the pixel, row by row, the pixel in the middle, and the
// pixel must be changing. A moving light or caster, or a lamp that switches, changes the light of a band many pixels wide,
// which the opening keeps. The jitter that moves a pixel on and off a still feature thinner than a pixel changes its
// record too, in a line one or two pixels wide, which the opening removes. The cost: a real change on such a line counts
// as none. FSR's light-change mask (lightChangeMaskAt) reads this frame's records, and the light-age record (lightAgeOf)
// the last frame's.
bool insideChangedArea(bool changing[5][5])
{
    for (int y = 0; y < 3; y++)
        for (int x = 0; x < 3; x++)
        {
            bool whole = true;
            for (int dy = 0; dy < 3; dy++)
                for (int dx = 0; dx < 3; dx++)
                    whole = whole && changing[y + dy][x + dx];
            if (whole)
                return true;
        }
    return false;
}

// FSR 3.1's transparency and composition mask at the pixel (ticket t1-4hij), from this frame's light-age records: 1 where
// the change of the pixel's light covers an area (insideChangedArea), else 0. Under the mask FSR clamps its history to the
// pixel's neighbors in this frame, so a still surface under a moving light does not keep the light of the light's earlier
// places. Under the mask FSR's clamp would follow the jitter's aliasing on a line, which the area rule leaves out. The
// resolve writes it, after the plan wrote every record.
float lightChangeMaskAt(ivec2 pixel)
{
    // An opening holds only pixels that change: one read decides the still pixels.
    if (!changingLight(imageLoad(lightAge, pixel).g))
        return 0.0;
    ivec2 last = ivec2(frame.viewport.xy) - 1;
    bool changing[5][5];
    for (int y = 0; y < 5; y++)
        for (int x = 0; x < 5; x++)
            changing[y][x] = changingLight(imageLoad(lightAge, clamp(pixel + ivec2(x - 2, y - 2), ivec2(0), last)).g);
    return insideChangedArea(changing) ? 1.0 : 0.0;
}

#ifdef TERTIUS_LIGHT_AGE_DIAGNOSTIC
// The diagnostic of uncovered surfaces (TemporalSignal.UncoveredDiagnostic), which only the capture tool and the tests
// read: the resolve writes r, the fewest frames seen among the never-changed surfaces that the specular sample's rays
// hit, or −1 for none. The temporal dispatch writes the other channels.
layout(set = 3, binding = 19, rgba32f) uniform writeonly image2D uncoveredDiagnostic;

// The age of a ray that hit nothing: below every record's age, so that a miss differs from a surface first shown.
const float MissLightAge = -65536.0;

// The diagnostic's field of a ray record, the 14 bits of the light code (RecordCodeBits): an age code below SeenField, or
// SeenField plus a never-changed hit's frames seen. Its age codes stop at MostFieldCode, age 8,190, which changes no cut
// while the history holds fewer frames.
const uint SeenField = 0x2000u;
const uint MostFieldCode = 0x1FFFu;

uint rayFieldOf(float age)
{
    if (age >= 0.0)
        return min(ageCodeOf(age), MostFieldCode);
    if (age > MissLightAge)
        return SeenField | uint(min(-age - 1.0, float(MostFieldCode)));
    return 0u;
}

// The seen code of a ray record: 0 for none, else the frames seen of its never-changed hit plus 1.
uint seenCodeOfRecord(uvec4 ray)
{
    uint field = (ray.w >> 1) & RecordCodeBits;
    return (field & SeenField) != 0u ? (field & MostFieldCode) + 1u : 0u;
}
#endif

// The age code of a ray record's hit (ageCodeOf), without the moved mark.
uint ageCodeOfRecord(uvec4 ray)
{
    uint field = (ray.w >> 1) & RecordCodeBits;
#ifdef TERTIUS_LIGHT_AGE_DIAGNOSTIC
    return (field & SeenField) != 0u ? 0u : field;
#else
    return field;
#endif
}

// Whether a ray record's hit carries the moved mark.
bool movedHitOfRecord(uvec4 ray)
{
    return (ray.w & RecordMovedMark) != 0u;
}
#endif

HISTORY_READER(lastFastSpecularAt, lastFastSpecular)
HISTORY_READER(slowSpecularAt, slowSpecular)

// ScreenTracePushConstants.
layout(push_constant, std430) uniform ScreenTracePush
{
    uint drawIndex;          // the draw's index since the last reset (section 6, "Randomness")
    uint reflectionSteps;    // the caps of decision 41
    float reflectionCeiling; // GuidedShares.ReflectionCeiling, or 0 with the guiding off
    float rampStart;         // GuidedShares.RampStart and RampEnd, roughnesses
    float rampEnd;
    float shareStep;         // GuidedShares.Step, Guard, MostRatio and MostEvidenceWeight
    float shareGuard;
    float shareMostRatio;
    float mostEvidenceWeight;
    uint sharesRestart;      // 1 when every tile's share restarts at the ceiling before this draw (ScreenTraceImages.SharesRestart)
} trace;

// Set for a pixel with an individual ray.
const uint PlanOwnReflection = 1u;

// The largest weight of a ray at a pixel, which trades a small bias for no fireflies (section 6, "The resolve").
const float MostRayWeight = 4.0;

// The least cosine of a block ray at its chosen pixel, 2^-14, by which the resolve divides.
const float LeastRayCosine = 0.00006103515625;

// The constants of pcg3d's third value, one per use: a direction takes two dimensions from one draw, its x and y.
const uint DirectionDraw = 0x5245u;   // "RE"
const uint TurnDraw = 0x5254u;        // the block's turn
// The guided draw: the descent's levels, three per draw from "GD" on, and the target's place in its slab, "GT".
const uint GuideDraw = 0x4744u;
const uint TargetDraw = 0x4754u;
// A reflection ray's guided draw adds this salt to both constants, so that a pixel's two rays do not aim at the same
// target in a draw.
const uint ReflectionGuideSalt = 0x0100u;
// A reflection ray's turn of the guided draw (guidedTurn): a hash per group of 2 × 2 cells and window of 4 draws, "RP",
// and a phase per cell, "RC".
const uint TurnWindowDraw = 0x5250u;
const uint TurnPhaseDraw = 0x5243u;

// The depth of the box that a guided reflection ray aims at, as a share of the target's depth
// (LightPyramid.TargetDepthShare). It is no thickness: a guided ray that the walk rejects behind a thin surface counts
// as a miss (https://github.com/alexispurslane/tertius/wiki/back-face-depth-layer, decision 7).
const float TargetDepthShare = 0.05;

// The reflection rays' blue-noise mask (BlueNoiseMask), which blue_noise.glsl reads.
layout(set = 0, binding = 20) uniform utexture2D blueNoiseMask;
#include "blue_noise.glsl"

// The draw of a pixel or a block: pcg3d of its packed position, the draw index and a constant per use.
uvec3 drawOf(ivec2 position, uint drawIndex, uint constant)
{
    return pcg3d(uvec3(packedPixel(position), drawIndex, constant));
}

// A word as a float in [0, 1), from its 24 high bits, which a float holds exactly.
float unitOf(uint word)
{
    return float(word >> 8) * (1.0 / 16777216.0);
}

// The two numbers of a reflection ray's GGX draw, (angle, radial), from the mask: each byte picks a step of 1/256, and
// 16 bits of the draw place the number inside it. The sum is an integer below 2^24, which a float holds exactly, so a
// number stays below 1.
vec2 reflectionNumbersOf(ivec2 cell, uint drawIndex, uvec3 draw)
{
    uvec2 bytes = blueNoiseBytesOf(cell, drawIndex);
    uvec2 numbers = (bytes.yx << 16) | (draw.xy >> 16);
    return vec2(numbers) * (1.0 / 16777216.0);
}

// A pixel that starts a ray, and what its rays need.
struct TracingPixel
{
    ShadingInput s;
    vec3 normal;            // the normal of the rays' lobes: the shading normal, a hair pixel's fiber normal
    vec3 V;                 // toward the eye
    vec3 point;             // the surface point, camera-relative
    vec3 origin;            // the rays' start: the surface point off the geometric surface, as today's trace starts
    float viewDepth;
    float alpha;            // the floored roughness squared
    uint ownCard;           // a hair pixel's card code, NoCard for another model
};

// Whether the pixel holds a lit surface whose rays the tracer traces: not sky and not an impostor, whose light the atlas
// holds.
bool tracedSurface(ivec2 pixel)
{
    return texelFetch(gbufferDistance, pixel, 0).r > 0.0 && texelFetch(gbufferBaseColor, pixel, 0).a != 0.0;
}

// The pixel's surface for its rays. The pixel must hold a traced surface.
TracingPixel tracingPixelAt(ivec2 pixel)
{
    TracingPixel p;
    p.s = materialAt(pixel);
    vec3 ray = viewRayThrough(vec2(pixel) + 0.5);
    vec3 toSurface = normalize(ray);
    float distanceToEye = texelFetch(gbufferDistance, pixel, 0).r;
    p.V = -toSurface;
    p.normal = p.s.model == ShadingHair ? fiberNormal(p.s.strand, p.V, p.s.normal) : p.s.normal;
    p.viewDepth = distanceToEye / length(ray);
    p.point = p.s.position;
    p.origin = p.point + p.s.geometricNormal * originOffset(p.viewDepth);
    float roughness = flooredRoughness(p.s.roughness);
    p.alpha = roughness * roughness;
    uvec4 shading = texelFetch(gbufferShading, pixel, 0);
    p.ownCard = cardOfWords(shading.b, shading.a);
    return p;
}

// The composite uses only environment light at the roughness limit.
bool startsReflection(TracingPixel p)
{
    return sqrt(p.alpha) < maxTraceRoughness;
}

// The block's chosen pixel for the kind: the first pixel of the block's turn that starts the ray (section 6, "The ray
// budget"), or false when none does. The plan, the block's ray and the resolve call it, so all three choose the same
// pixel.
bool chosenPixelOf(ivec2 block, out ivec2 chosen, out TracingPixel p)
{
    uint turn = trace.drawIndex + drawOf(block, 0u, TurnDraw).x;
    for (uint k = 0u; k < 4u; k++)
    {
        uint corner = (turn + k) & 3u;
        chosen = 2 * block + ivec2(corner & 1u, corner >> 1);
        if (all(lessThan(vec2(chosen), frame.viewport.xy)) && tracedSurface(chosen))
        {
            p = tracingPixelAt(chosen);
            if (startsReflection(p))
                return true;
        }
    }
    return false;
}

// The unit tangent and bitangent of a unit normal (Duff et al. 2017), with no branch on the pole.
void basisOf(vec3 n, out vec3 tangent, out vec3 bitangent)
{
    float s = n.z >= 0.0 ? 1.0 : -1.0;
    float a = -1.0 / (s + n.z);
    float b = n.x * n.y * a;
    tangent = vec3(1.0 + s * n.x * n.x * a, s * b, -s * n.x);
    bitangent = vec3(b, s + n.y * n.y * a, -n.y);
}

// The density per steradian of a reflection ray along `direction` from the pixel: GGX's visible normals at the pixel's
// alpha, D(h) G1(v) / (4 n·v), with n·v floored at MinNdotV.
float reflectionDensity(TracingPixel p, vec3 direction)
{
    float nv = max(dot(p.normal, p.V), MinNdotV);
    vec3 h = halfVectorOf(direction, p.V, p.normal);
    float alphaSq = p.alpha * p.alpha;
    float lambdaPart = nv + sqrt(alphaSq + (1.0 - alphaSq) * nv * nv);
    return ggxDistribution(p.normal, h, p.alpha) / (2.0 * lambdaPart);
}

// A reflection ray: the view direction reflected about a half vector from GGX's visible normals at alpha, sampled by
// spherical caps (Dupuy and Benyoub 2023).
vec3 reflectionDirection(TracingPixel p, vec2 u)
{
    vec3 tangent, bitangent;
    basisOf(p.normal, tangent, bitangent);
    // A normal map can turn the shading normal from the eye: the floor keeps the sample in the upper hemisphere.
    float nv = max(dot(p.normal, p.V), MinNdotV);
    vec3 v = normalize(vec3(dot(p.V, tangent), dot(p.V, bitangent), nv));
    vec3 stretched = normalize(vec3(v.xy * p.alpha, v.z));
    float phi = 2.0 * PI * u.x;
    float z = (1.0 - u.y) * (1.0 + stretched.z) - stretched.z;
    float sine = sqrt(clamp(1.0 - z * z, 0.0, 1.0));
    vec3 cap = vec3(sine * cos(phi), sine * sin(phi), z) + stretched;
    vec3 h = normalize(vec3(cap.xy * p.alpha, max(cap.z, 0.0)));
    return reflect(-p.V, h.x * tangent + h.y * bitangent + h.z * p.normal);
}

// On a miss, use the receiver’s environment along the sampled reflection direction, occluded by the light volume when active.
vec3 missLightOf(TracingPixel p, ivec2 pixel, vec3 direction)
{
    vec3 light;
    if (environmentMapOn)
        light = environmentSpecular(p.s.map, p.s.position, direction, p.s.geometricNormal, sqrt(p.alpha),
                withAmbientFootprint(p.s, pixel).reflectionFootprint);
    else
        light = mix(frame.ambientGround.rgb, frame.ambientSky.rgb,
            p.s.lobeSkyFraction);
    if (lightVolumeOn)
        light *= volumeTransmissionAt(p.s.position, p.s.geometricNormal, direction);
    return min(light, vec3(GlossyRadianceLimit));
}

// Reproject the previous reflection in its unchanged scene-radiance units.
vec3 lastLightOf(Reprojection r)
{
    return lastFastSpecularAt(r).rgb;
}

// Whether the pixel's surface moved since the last draw, as the surface test pass found it (signals.glsl, SurfaceMoved).
bool movedSurfaceAt(ivec2 pixel)
{
    return (imageLoad(surfaceTest, pixel).r & SurfaceMoved) != 0u;
}

// Whether the pixel's own surface point moves on screen by at least LeastMotion pixels, as the surface test pass found it
// (signals.glsl, SurfaceMovesOnScreen).
bool movesOnScreenAt(ivec2 pixel)
{
    return (imageLoad(surfaceTest, pixel).r & SurfaceMovesOnScreen) != 0u;
}

// The reprojection of a pixel into the last frame for each signal, by the surface test's pass bits at the pixel.
struct SignalReprojections
{
    Reprojection diffuse;
    Reprojection specular;
};

SignalReprojections reprojectionsAt(ivec2 pixel)
{
    return SignalReprojections(surfaceReprojectionAt(pixel),
        reprojectionOf(lastPlaceAt(pixel), specularPassBits(imageLoad(surfaceTest, pixel).r)));
}

// Radiance available at a screen-space hit, including its reprojected glossy reflection.
vec3 leavingLightOf(ivec2 q, ShadingInput s, vec3 V, SignalReprojections r)
{
    MaterialFactors factors = materialFactors(s, lobesOf(s, V));
    IndirectLight closedLight = closedFormScene(withAmbientFootprint(s, q), V);
    vec3 indirectDiffuse = factors.diffuse * closedLight.diffuse;
    vec3 indirectSpecular = factors.specular * closedLight.specular;
    if (lightVolumeOn)
        applyLightVolume(s, V, factors, holdsHistory(r.specular), indirectDiffuse, indirectSpecular);
    vec3 light = sentDiffuseLight(q, imageLoad(directDiffuseLight, q).rgb, r.diffuse)
        + indirectDiffuse;
    float share = glossyShare(s.roughness);
    vec3 specular = indirectSpecular;
    if (share > 0.0 && holdsHistory(r.specular))
        specular = mix(specular, factors.specular * lastLightOf(r.specular), share);
    vec3 reflection = light
        + surfaceShare(r.diffuse) * imageLoad(directSpecularLight, q).rgb + specular;
    return min(reflection, vec3(GlossyRadianceLimit));
}

// The light that leaves the pixel q of an impostor toward a ray of either kind: the glow that it sends, times its
// surface share (sent_light.glsl). An impostor's glow holds all of its light.
vec3 impostorLightAt(ivec2 q)
{
    vec3 glow = sentDiffuseLight(q, vec3(0.0), surfaceReprojectionAt(q));
    return glow;
}

// The light that leaves the pixel q toward a ray for reflections: leavingLightOf, or impostorLightAt for an impostor.
vec3 leavingLightAt(ivec2 q)
{
    if (texelFetch(gbufferBaseColor, q, 0).a == 0.0)
        return impostorLightAt(q);
    return leavingLightOf(q, materialAt(q), -normalize(viewRayThrough(vec2(q) + 0.5)), reprojectionsAt(q));
}

// Whether a walk can hit the pixel, inside the viewport: its finest depth lies in front of the eye (walkScreen). The sky's
// is 0.
bool hittable(ivec2 pixel)
{
    return texelFetch(depthFinest, pixel, 0).r > 0.0;
}

// The guide light of a cell of the light pyramid's level, 0 beyond the level's image, whose fetch is undefined.
float pyramidLightAt(int level, ivec2 cell)
{
    if (level == 0)
        return all(lessThan(cell, textureSize(lightFinest, 0))) ? texelFetch(lightFinest, cell, 0).r : 0.0;
    return all(lessThan(cell, textureSize(lightLevels, level - 1))) ? texelFetch(lightLevels, cell, level - 1).r : 0.0;
}

// The guide light of the whole screen: the top level's one cell. 0 when no lit pixel is in view.
float guideTotal()
{
    return texelFetch(lightLevels, ivec2(0), textureQueryLevels(lightLevels) - 1).r;
}

// The pixel at which a guided ray from `pixel` aims, each pixel in proportion to its guide light: from the top, each level
// takes a child in proportion to its light (LightPyramid.Drawn). The total must be above 0.
ivec2 guidedTargetOf(ivec2 pixel, uint salt)
{
    int top = textureQueryLevels(lightLevels);
    ivec2 cell = ivec2(0);
    // Each draw gives the random units of three levels.
    uvec3 draw = uvec3(0u);
    for (int level = top; level >= 1; level--)
    {
        int index = top - level;
        if (index % 3 == 0)
            draw = drawOf(pixel, trace.drawIndex, GuideDraw + salt + uint(index / 3));
        float unit = unitOf(draw[index % 3]);
        float lights[4];
        float total = 0.0;
        for (int child = 0; child < 4; child++)
        {
            lights[child] = pyramidLightAt(level - 1, 2 * cell + ivec2(child & 1, child >> 1));
            total += lights[child];
        }
        float reach = unit * total;
        int chosen = 0;
        float below = 0.0;
        for (int child = 0; child < 4; child++)
        {
            if (lights[child] <= 0.0)
                continue;
            chosen = child;
            below += lights[child];
            if (reach < below)
                break;
        }
        cell = 2 * cell + ivec2(chosen & 1, chosen >> 1);
    }
    return cell;
}

// The point at which a guided ray from `pixel` aims in its target pixel: a uniform point of the target's box, its volume
// from its center's depth to TargetDepthShare behind it (LightPyramid.TargetOf), with the salt of guidedTargetOf.
vec3 guidedPointOf(ivec2 pixel, ivec2 target, uint salt)
{
    uvec3 draw = drawOf(pixel, trace.drawIndex, TargetDraw + salt);
    vec2 place = vec2(target) + vec2(unitOf(draw.x), unitOf(draw.y));
    return viewRayThrough(place) * ((1.0 + TargetDepthShare * unitOf(draw.z)) / texelFetch(depthFinest, target, 0).r);
}

// The end of a chord that no side of the slab ends (LightPyramid.NoEnd).
const float NoChordEnd = 1e30;

// The chord (t from x to y) where also α + β t ≥ 0 (LightPyramid.Chord.Inside).
vec2 chordInside(vec2 chord, float alpha, float beta)
{
    if (beta > 0.0)
        return vec2(max(chord.x, -alpha / beta), chord.y);
    if (beta < 0.0)
        return vec2(chord.x, min(chord.y, -alpha / beta));
    return alpha < 0.0 ? chord.xx : chord;
}

// (t / z)² at the distance t along the ray, z the point's view depth.
float squareOverDepth(float t, float originDepth, float along)
{
    float ratio = t / (originDepth + t * along);
    return ratio * ratio;
}

// The density per steradian of the directions of the guided rays from `origin` that aim at the pixel q, along
// `direction`, times the screen's guide light: q's guide light times the integral of t² over q's target box along the
// ray, over the box's volume element, and 0 where the ray misses the box or q has no light (LightPyramid.PixelDensity).
// A pixel without light, most of the 3 × 3 around a hit in a dark region, returns before its depth's fetch.
float pixelDensityOf(vec3 origin, vec3 direction, ivec2 q)
{
    bool inside = all(greaterThanEqual(q, ivec2(0))) && all(lessThan(q, textureSize(lightFinest, 0)));
    float light = inside ? texelFetch(lightFinest, q, 0).r : 0.0;
    if (light <= 0.0)
        return 0.0;
    float w = texelFetch(depthFinest, q, 0).r;
    if (w <= 0.0)
        return 0.0;
    float front = 1.0 / w;
    float back = (1.0 + TargetDepthShare) / w;
    vec3 forward = frame.cameraForward.xyz;
    float originDepth = dot(origin, forward);
    float along = dot(direction, forward);
    // The chord of the ray through the box: t from 0 where every side of the box holds the ray's point.
    vec2 chord = chordInside(chordInside(vec2(0.0, NoChordEnd), originDepth - front, along), back - originDepth, -along);
    vec3 right = frame.cameraRight.xyz / dot(frame.cameraRight.xyz, frame.cameraRight.xyz);
    vec3 up = frame.cameraUp.xyz / dot(frame.cameraUp.xyz, frame.cameraUp.xyz);
    for (int side = 0; side < 2; side++)
    {
        // The pixel's columns and rows, each edge a plane through the eye, as pixelOf places the jittered pixels.
        vec2 edge = (vec2(q + side) + frame.renderParams.yz) * frame.viewport.zw * 2.0 - 1.0;
        float facing = side == 0 ? 1.0 : -1.0;
        vec3 acrossX = (right - edge.x * forward) * facing;
        vec3 acrossY = (-up - edge.y * forward) * facing;
        chord = chordInside(chord, dot(origin, acrossX), dot(direction, acrossX));
        chord = chordInside(chord, dot(origin, acrossY), dot(direction, acrossY));
    }
    if (chord.y <= chord.x)
        return 0.0;
    // Simpson's rule over the chord: z changes by at most TargetDepthShare inside the box, so t² / z² is nearly a
    // quadratic in t, which the rule integrates exactly.
    float squares = (chord.y - chord.x) / 6.0 * (squareOverDepth(chord.x, originDepth, along)
        + 4.0 * squareOverDepth(0.5 * (chord.x + chord.y), originDepth, along) + squareOverDepth(chord.y, originDepth, along));
    // The pixel's area at depth 1, 4 tan h tan v / (width · height), times the box's depth: a uniform point of the box
    // has the density 1 / (A z² dz).
    float areaDepth = 4.0 * length(frame.cameraRight.xyz) * length(frame.cameraUp.xyz) * frame.viewport.z
        * frame.viewport.w * (back - front);
    return light * squares / areaDepth;
}

// The density per steradian with which a guided ray from `origin` runs along `direction` and counts, and whether one that
// aims at `target` counts: it counts when the walk hits a pixel of the 3 × 3 around its target, and it crosses the
// target's box. So the density sums pixelDensityOf over the 3 × 3 pixels around the hit, in rows from the top, over the
// screen's guide light, which must be above 0 (ARCHITECTURE.md, "Guided rays", LightPyramid.GuidedDensity and
// Counts).
float guidedDensityOf(vec3 origin, vec3 direction, ivec2 hit, ivec2 target, out bool counts)
{
    float density = 0.0;
    counts = false;
    for (int y = -1; y <= 1; y++)
        for (int x = -1; x <= 1; x++)
        {
            ivec2 q = hit + ivec2(x, y);
            float pixel = pixelDensityOf(origin, direction, q);
            density += pixel;
            counts = counts || all(equal(q, target)) && pixel > 0.0;
        }
    return density / guideTotal();
}

// The density of the one-sample mixture of a lobe draw and the guided draw at the share (GuidedShares.MixtureDensity).
float mixtureDensity(float share, float lobeDensity, float guidedDensity)
{
    return (1.0 - share) * lobeDensity + share * guidedDensity;
}

// The reflection share that the pixel's roughness allows: 0 up to rampStart, rising linearly to the ceiling at rampEnd
// (GuidedShares.ReflectionShareOf). A sharp lobe gives a guided direction almost no density, so its guided draw would
// waste the ray.
float reflectionRampOf(TracingPixel p)
{
    return trace.reflectionCeiling * clamp((sqrt(p.alpha) - trace.rampStart) / (trace.rampEnd - trace.rampStart), 0.0, 1.0);
}

// The reflection share of the tiles around the pixel's block, bilinear between the tiles' centers and clamped to the
// tiles that the render size covers: the ceiling while the shares restart (GuidedShares.TileShareAt). A block's four
// pixels read the same share. A block's center lies an odd multiple of 1 / 16 of a tile from a tile's center, so the
// weights are exact.
float tileShareAt(ivec2 pixel)
{
    if (trace.sharesRestart != 0u)
        return trace.reflectionCeiling;
    ivec2 tiles = ((ivec2(frame.viewport.xy) + 1) / 2 + TileBlocks - 1) / TileBlocks;
    vec2 place = clamp((vec2(pixel / 2) + 0.5) / float(TileBlocks), vec2(0.5), vec2(tiles) - 0.5) - 0.5;
    ivec2 low = ivec2(place);
    ivec2 high = min(low + 1, tiles - 1);
    vec2 f = place - vec2(low);
    float top = mix(imageLoad(reflectionShare, low).r, imageLoad(reflectionShare, ivec2(high.x, low.y)).r, f.x);
    float bottom = mix(imageLoad(reflectionShare, ivec2(low.x, high.y)).r, imageLoad(reflectionShare, high).r, f.x);
    return mix(top, bottom, f.y);
}

// Whether the pixel's reflection rays take part in the guiding: its roughness lies above the ramp's start, the guiding is
// on, and a lit pixel is in view. Only then can a ray take the guided draw, or find the guided density that its tile's
// evidence needs.
bool guidesReflectionsOf(TracingPixel p)
{
    return reflectionRampOf(p) > 0.0 && guideTotal() > 0.0;
}

// The fraction of reflection rays steered toward the light pyramid, capped by the receiving lobe.
float guidedShareOf(TracingPixel p, ivec2 pixel)
{
    return guidesReflectionsOf(p) ? min(reflectionRampOf(p), tileShareAt(pixel)) : 0.0;
}

// Whether the reflection ray of the cell takes the guided draw in the draw, at the share: on a fixed pattern in time, an
// exact count where a coin is random. Where the guided draws bring nothing, a coin adds s / (1 − s) of the squared mean to
// the variance, and an exact count only the factor 1 / (1 − s) (ter-fe63). Within each window of 4 draws, the 2 × 2 cells
// of a group take the four slots of a Bayer pattern, turned by a hash of the group and the window: each slot holds a
// quarter of the cells, so the frame has no beat, and a block's guided ray does not keep to one pixel of the block, whose
// chosen pixel turns with a period of 4 (chosenPixelOf). Across the windows, a Van der Corput sequence shifted by a hash
// per cell places the share's fraction of the slot: the count stays exact within one at any share, and a change of the
// share moves no cell's phase.
bool guidedTurn(ivec2 cell, uint drawIndex, float share)
{
    const uint bayer[4] = uint[4](0u, 3u, 1u, 2u);
    uint window = drawIndex >> 2;
    uint turn = drawOf(cell >> 1, window, TurnWindowDraw).x;
    uint slot = ((drawIndex & 3u) + bayer[(cell.x & 1) + 2 * (cell.y & 1)] + (turn & 3u)) & 3u;
    uint order = ((slot & 1u) << 1) | (slot >> 1);
    float sequence = float(bitfieldReverse(window) >> 8) * (1.0 / 16777216.0);
    float phase = unitOf(drawOf(cell, 0u, TurnPhaseDraw).x);
    return (float(order) + min(fract(sequence + phase), 0.99999994)) * 0.25 < share;
}


// The 16-bit units of a unit direction's octahedral code.
uvec2 directionCodeOf(vec3 direction)
{
    return uvec2(clamp(octEncode(direction) * 0.5 + 0.5, 0.0, 1.0) * 65535.0 + 0.5);
}

vec3 directionOfCode(uvec2 code)
{
    return octDecode(vec2(code) * (2.0 / 65535.0) - 1.0);
}

// The result of one ray.
struct TracedRay
{
    vec3 direction;
    float density;        // the mixture density at the ray's share, which is the lobe density at a share of 0
    float lobeDensity;    // the density of the kind's lobe draw along the direction
    float guidedDensity;  // the guided density along the direction, for a ray that finds it (traceFrom), else 0
    float share;          // the ray's guided share (guidedShareOf)
    vec3 light;       // the hit's light faded into the miss's, in scene units; 0 for a ray that traced nothing
    float distance;   // from the ray's start to the hit, in m; 0 for a miss
    bool traced;      // false for a direction below the pixel's geometric plane, which brings no light
#ifdef TERTIUS_PRECISE_SPECULAR_HISTORY
    float age;        // the light age of the hit's pixel, NoLightAge for a miss (MissLightAge under the diagnostic)
    bool moved;       // whether the hit's pixel carries the plan's moved mark (movedSurfaceAt); false for a miss
#endif
};

// Traces the ray of the kind from the pixel that starts it: its draw, its walk to the kind's cap, and its light. A
// direction below the geometric plane brings no light and traces nothing (section 6, "The ray kinds"). `cell` is the
// ray's cell of the blue-noise mask: its block for a block's ray, its pixel for a pixel's own ray.
TracedRay traceFrom(ivec2 pixel, ivec2 cell, TracingPixel p)
{
    TracedRay result;
    uvec3 draw = drawOf(pixel, trace.drawIndex, DirectionDraw);
    vec2 u = reflectionNumbersOf(cell, trace.drawIndex, draw);
    float share = guidedShareOf(p, pixel);
    bool guided = share > 0.0 && guidedTurn(cell, trace.drawIndex, share);
    // A rough reflection ray finds its guided density at a share of 0 too: its tile's evidence needs it, so that a tile at
    // 0 can rise again.
    bool findsGuidedDensity = guidesReflectionsOf(p);
    ivec2 target = ivec2(-1);
    vec3 drawn;
    if (guided)
    {
        uint salt = ReflectionGuideSalt;
        target = guidedTargetOf(pixel, salt);
        drawn = normalize(guidedPointOf(pixel, target, salt) - p.origin);
    }
    else
        drawn = reflectionDirection(p, u);
    // The record holds the direction's code, and the resolve weighs the ray by the code's direction. So an unguided
    // reflection ray walks that direction, and its density is that direction's: at the roughness floor, the rounding of
    // the code alone moves D(h) by several percent. A ray of a share above 0 walks its drawn direction: the guided density
    // is a box function of the direction, and a rounded direction near a box's edge would count where its draw did not
    // land, which loses light. Its lobe density and weight are smooth at the ramp's roughnesses, so the code's rounding
    // moves them by far less than a percent.
    result.direction = share <= 0.0 ? directionOfCode(directionCodeOf(drawn)) : drawn;
    result.lobeDensity = reflectionDensity(p, result.direction);
    result.density = result.lobeDensity;
    result.guidedDensity = 0.0;
    result.share = share;
    result.light = vec3(0.0);
    result.distance = 0.0;
    result.traced = dot(result.direction, p.s.geometricNormal) > 0.0;
#ifdef TERTIUS_LIGHT_AGE_DIAGNOSTIC
    result.age = MissLightAge;
#elif defined(TERTIUS_PRECISE_SPECULAR_HISTORY)
    result.age = NoLightAge;
#endif
#ifdef TERTIUS_PRECISE_SPECULAR_HISTORY
    result.moved = false;
#endif
    if (!result.traced)
        return result;
    ScreenWalk walk = screenWalkOf(screenRayOf(p.origin, result.direction, p.viewDepth), result.direction, p.ownCard);
    vec2 hit;
    ivec2 hitPixel;
    float entryShare;
    uint steps = trace.reflectionSteps;
    vec3 missLight = missLightOf(p, pixel, result.direction);
    result.light = missLight;
    if (walkScreen(depthFinest, depthPyramid, walk, steps, hit, hitPixel, entryShare) != WalkHit)
    {
        // A miss has no guided density. A guided ray counts only where it hits a pixel near its target, so a miss brings
        // nothing.
        result.density = mixtureDensity(share, result.lobeDensity, 0.0);
        if (guided)
            result.light = vec3(0.0);
        return result;
    }
    if (findsGuidedDensity)
    {
        bool counts;
        result.guidedDensity = guidedDensityOf(p.origin, result.direction, hitPixel, target, counts);
        result.density = mixtureDensity(share, result.lobeDensity, result.guidedDensity);
        if (guided && !counts)
        {
            result.light = vec3(0.0);
            return result;
        }
    }
    // The hit's surface point from its own distance, not from the ray's inverse depth, which is coarse far away.
    vec3 hitPoint = normalize(viewRayThrough(hit)) * texelFetch(gbufferDistance, hitPixel, 0).r;
    result.distance = length(hitPoint - p.origin);
    float fade = edgeFade(hit) * (1.0 - entryShare);
    vec4 leaving = imageLoad(hitLight, hitPixel);
    result.light = mix(missLight, leaving.rgb, fade);
#ifdef TERTIUS_PRECISE_SPECULAR_HISTORY
    if (fade > 0.0)
    {
        result.age = imageLoad(lightAge, hitPixel).g;
        result.moved = leaving.a != 0.0;
    }
#endif
    return result;
}

// The weight of a ray's light in the pixel's specular sample before the cap MostRayWeight: the pixel's f_s(ω) cos θ along
// the direction over the ray's density, divided by the specular factor (Stachowiak 2015). For the pixel's own reflection
// ray it is F(v·h) G2 / (G1 E), whose mean over the lobe is 1.
vec3 uncappedSpecularWeightOf(TracingPixel p, SurfaceLobes lobes, MaterialFactors factors, vec3 direction, float density)
{
    vec3 response = p.s.model == ShadingHair ? hairResponse(p.s, lobes, p.V, direction).specular
        : specularResponse(lobes, p.s.normal, p.V, direction, 0.0);
    return response / (density * max(factors.specular, vec3(LeastFactor)));
}

// The evidence of a block's reflection ray from the pixel for its tile's share (GuidedShares.EvidenceOf): x the slope in
// the share of the mean of w², w² (l − g) / q, and y the moment w². w is the luminance that the ray adds to the pixel's
// specular sample before the cap of a ray's weight, at most mostEvidenceWeight; l, g and q are its lobe, guided and
// mixture densities, q at the share max(share, shareGuard). Zero where the ray brings no light, where the pixel's
// reflection rays take no part in the guiding (guidesReflectionsOf), and at the top of the hand-over band, above which no
// pixel traces a reflection ray. The sums of a tile stay finite: |l − g| / q is at most 1 / shareGuard, and w² at most
// mostEvidenceWeight².
vec2 shareEvidenceOf(TracingPixel p, TracedRay ray)
{
    if (!ray.traced || ray.density <= 0.0 || !guidesReflectionsOf(p))
        return vec2(0.0);
    SurfaceLobes lobes = lobesOf(p.s, p.V);
    vec3 weight = uncappedSpecularWeightOf(p, lobes, materialFactors(p.s, lobes), ray.direction, ray.density);
    float w = luminance(glossyShare(sqrt(p.alpha)) * ray.light * weight);
    if (!(w > 0.0))
        return vec2(0.0);
    w = min(w, trace.mostEvidenceWeight);
    float moment = w * w;
    float mixture = mixtureDensity(max(ray.share, trace.shareGuard), ray.lobeDensity, ray.guidedDensity);
    return vec2(moment * (ray.lobeDensity - ray.guidedDensity) / mixture, moment);
}

// The half bits of log2 of a density: a reflection ray's density passes 65,504, the largest half float, at the roughness
// floor below an n·v of about 0.3, and its logarithm stays near 17 there. A density below LeastDensity
// encodes as ZeroDensityCode, which decodes to exactly 0. Both ends test for it: the Vulkan
// spec leaves log2 of 0 undefined, and exp2's error at −65,504 allows a denormal, which the resolve's weights would
// divide by.
const float LeastDensity = 7.888609052210118e-31;  // 2^-100, a normal float
const uint ZeroDensityCode = 0xFBFFu;              // the half bits of −65,504, the least half

uint densityCodeOf(float density)
{
    return density >= LeastDensity ? packHalf2x16(vec2(log2(density), 0.0)) & 0xffffu : ZeroDensityCode;
}

float densityOfCode(uint code)
{
    return code == ZeroDensityCode ? 0.0 : exp2(unpackHalf2x16(code).x);
}

// A ray's record: its light and hit distance, and its direction, density and RayTraced.
struct RayRecord
{
    vec4 light;
    uvec4 ray;
};

// The farthest hit distance that a record holds, in m: the largest half float, past which a GPU that is not Metal stores
// infinity. A farther hit, such as a planet's, stores it. At 1080p and 60°, its reflected place then lies about 2 px off
// the true one when the camera moves 117 m per frame, an orbit's speed. The same-hit test compares capped distances alike.
const float MostHitDistance = 65504.0;

RayRecord recordOf(TracedRay traced)
{
    RayRecord record;
    record.light = vec4(traced.light, min(traced.distance, MostHitDistance));
    record.ray = uvec4(directionCodeOf(traced.direction), densityCodeOf(traced.density), traced.traced ? RayTraced : 0u);
#ifdef TERTIUS_PRECISE_SPECULAR_HISTORY
    // The hit's age code in the 14 bits above RayTraced, and its moved mark above them.
#ifdef TERTIUS_LIGHT_AGE_DIAGNOSTIC
    record.ray.w |= rayFieldOf(traced.age) << 1;
#else
    record.ray.w |= ageCodeOf(traced.age) << 1;
#endif
    record.ray.w |= traced.moved ? RecordMovedMark : 0u;
#endif
    return record;
}

// The record of a block with no ray: no pixel of it starts the kind.
RayRecord noRay()
{
    RayRecord record;
    record.light = vec4(0.0);
    record.ray = uvec4(0u);
    return record;
}

#endif
