import pathlib, subprocess, os, json, time, hashlib
root=pathlib.Path(__file__).resolve().parent.parent.parent
out=root/'fsr-reference-investigation'/'source-isolation'
verification=json.loads((root/'local-verification-summary.json').read_text())
records=[]
for tree in ['before','after']:
    source=root/('local-source-'+tree)
    for name,expected in verification['trees'][tree]['production_source_sha256'].items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest()==expected, name
    commands=[('build',['nix','develop',str(source),'--command','dotnet','build','tests/Tertius.Host.Tests','-c','Release','-nologo','-v:q','-p:RunAnalyzers=false']),
              ('probe',['nix','develop',str(source),'--command','dotnet','tests/Tertius.Host.Tests/bin/Release/net11.0/Tertius.Host.Tests.dll','-method','Tertius.Host.Tests.LinuxExposureMeasurements.ReportDirectSourceIsolation','-explicit','only','-maxThreads','1','-noColor'])]
    for phase,command in commands:
        env=os.environ.copy()
        env.update(TERTIUS_LINUX_OUT=str(out/tree),TERTIUS_LINUX_VALIDATE='1')
        start=time.monotonic()
        with (out/(tree+'-'+phase+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
        record=dict(tree=tree,phase=phase,command=command,exit=result.returncode,elapsed_seconds=time.monotonic()-start)
        records.append(record)
        (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
        if result.returncode:
            (out/'exit.txt').write_text(str(result.returncode)+'\n')
            raise SystemExit(result.returncode)
(out/'exit.txt').write_text('0\n')
