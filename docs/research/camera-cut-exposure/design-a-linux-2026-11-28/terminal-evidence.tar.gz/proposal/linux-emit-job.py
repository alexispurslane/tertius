"""Write a reviewable PowerShell submit command. Never invoke that command.

The caller must supply final immutable SHAs and a recorded issue #4 approval.
The canonical GPU submit CLI remains the only component that can submit the job.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--proposal', action='store_true', help='Write an inert review copy with an unconditional PowerShell stop.')
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    if not args.proposal and (not config['approval']['coordinator_reviewed'] or not config['approval']['issue4_explicit_paid_approval']):
        raise ValueError('Do not create a launch command before coordinator review and explicit issue #4 approval.')
    for name in ['baseline_sha', 'candidate_sha', 'issue3_final_sha', 'main_baseline_sha']:
        value = config[name]
        if not isinstance(value, str) or len(value) != 40 or any(c not in '0123456789abcdef' for c in value):
            raise ValueError('Set final full commit SHAs first.')
        actual = subprocess.check_output(['git', 'rev-parse', value + '^{commit}'], cwd=args.repo, text=True).strip()
        if actual != value:
            raise ValueError('Commit SHA did not resolve exactly.')
    if config['baseline_sha'] != config['main_baseline_sha']:
        raise ValueError('Baseline is not the reviewed main commit with allocator fix #35.')
    if config['command_timeout_seconds'] > 840:
        raise ValueError('Canonical command limit is 840 seconds.')
    root = Path(__file__).resolve().parent
    payload = {}
    for name in ['linux-worker.py', 'linux-fixture.py']:
        payload[name] = (root / name).read_bytes()
    for name in ['issue4-cut-first-present.json', 'issue4-cut-outside-control.json', 'issue4-cut-return-control.json']:
        payload['linux-scripts/' + name] = subprocess.check_output(
            ['git', 'show', config['candidate_sha'] + ':scripts/' + name], cwd=args.repo)
    payload['linux-config.json'] = args.config.read_bytes()
    encoded = {name: base64.b64encode(data).decode() for name, data in payload.items()}
    bootstrap = ('import base64,json,pathlib,subprocess,sys\n'
        + 'payload=json.loads(' + repr(json.dumps(encoded)) + ')\n'
        + 'for name,data in payload.items():\n'
        + ' path=pathlib.Path(name);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(base64.b64decode(data))\n'
        + 'subprocess.run([sys.executable,"-I","linux-worker.py","--config","linux-config.json"],check=True)\n')
    shell = "python3 -c 'import base64;exec(base64.b64decode(\"" + base64.b64encode(bootstrap.encode()).decode() + "\"))'"
    argv = ['python3', '-I', 'tools/runpod/gpu_job.py', 'submit', '--agent', 'issue4-exposure',
        '--tree', 'before=' + config['baseline_sha'], '--tree', 'after=' + config['candidate_sha'],
        '--run', shell, '--timeout', str(config['command_timeout_seconds']), '--out', config['result_folder']]
    for output in ['linux-out/*.json', 'linux-out/*.jsonl', 'linux-out/*.csv', 'linux-out/*.patch',
                   'linux-out/*.log', 'linux-out/**/*.json.gz']:
        argv += ['--output', output]
    command = '& ' + ' '.join("'" + word.replace("'", "''") + "'" for word in argv) + '\n'
    if args.proposal:
        command = "throw 'Proposal only: no paid retry is approved. Record the parent decision and regenerate before submission.'\n" + command
    args.out.write_text(command)
    metadata = {'baseline': config['baseline_sha'], 'candidate': config['candidate_sha'],
        'command_timeout_seconds': config['command_timeout_seconds'],
        'worst_case_usd': (min(config['command_timeout_seconds'] + 60, 900) + 70) * 0.00016,
        'payload_sha256': {name: hashlib.sha256(data).hexdigest() for name,data in payload.items()},
        'submit_command_sha256': hashlib.sha256(command.encode()).hexdigest(),
        'submitted': False, 'proposal_only': args.proposal, 'approval': config['approval']}
    args.out.with_suffix('.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print('Wrote a launch command for review. No job was submitted.')


if __name__ == '__main__':
    main()
