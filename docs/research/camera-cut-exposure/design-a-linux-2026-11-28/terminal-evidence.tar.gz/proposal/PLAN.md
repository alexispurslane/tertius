# Linux comparison proposal for issue #4

This proposal submits no job. Both approval flags remain false. The previous approval covered only failed job 40d9f654-f5dc-4671-8a58-01c21712037f-u2, which cost $0.05953728. That approval authorizes no retry.

## Immutable inputs

| Input | Pin |
|---|---|
| Main baseline | b002351eb48d33f008f8333e53e61345de3260cd |
| Earlier production baseline | 19e17c5ba364392ca6bf84b00c11a7d709771ded |
| Final candidate | 588b6d2747560c73aac542fb25ce80eec1ba8db7 |
| Allocator Git blob, both inputs | f7aae7bd20d48ea3adf0d565ed476a6d2ec54594 |
| Allocator source patch SHA-256 | 61c94080b16aacd672c3ebc233590eeac63dc19d4d067dbd0d0eb3b70f800813 |
| GPU and driver | NVIDIA RTX 2000 Ada Generation, 595.112.07 |
| Cooked Linux asset manifest SHA-256 | 210510fe09f7195174b57d4491223a5721fc03c6a33325b4e24bbf0063319f75 |

The main baseline differs in production source from the earlier baseline only in the allocator. All 605 production files in the prepared plain baseline archive match main. The candidate must preserve the same allocator blob. The candidate stores glossy light in 32-bit linear scene radiance, in W/(m² sr). Its fixture must compile against the actual API and formats of both commits.

## Presentation and frame measurements

The cut observer reads eight bytes after each submitted draw completes: four bytes for applied exposure and four bytes for the center output pixel. It observes internal still warmups as separate presentations. Each explicit final capture must match the observer's final exposure and center pixel exactly. Independent destination references retain their normal still warmups.

Presentation latency starts at the camera request and ends at the fence completion of the first correct offscreen Vulkan submission. It excludes desktop composition, vblank and display scanout. The cut lane includes its observation and capture overhead in wall time. It writes no PNGs.

The ordinary lane requests neither captures nor observation copies. It continues the real scene for 120 frames and discards 24 warmup frames. Its 96 wall samples correspond to drawn frames. GPU timestamps report the preceding draw. Match actual GPU frame numbers to the measured interval, retaining 95 GPU samples. Never label a preceding draw's GPU cost as the current draw's cost.

Use native rendering at 1280 × 720 and FSR rendering at its observed 848 × 477 rectangle, with 1280 × 720 output. Synthetic scenes use 160 × 90 native or 96 × 54 FSR rendering. Both inputs use identical settings, the same worker and driver, and the same fixture bytes.

Run separate validating diagnostics with active-extent logging and histogram-clear, histogram-meter, and reduction/adaptation timestamps. Restore every changed production byte, verify hashes, and rebuild pristine binaries before ordinary measurements. Diagnostics are not ordinary-cost results.

## References and order

Compare both film cut directions at world ticks 1417 and 1462. Synthetic cases cover two source histories, ordinary and extreme dim destinations, compensation -13, fixed exposure and continuous movement. References use independent renderers. Require adjacent independent reference readings to settle within 1/16 stop and two sRGB code values per center channel.

Use two matched rounds, baseline then candidate, followed by candidate then baseline. Each process runs native and FSR, with cut and ordinary lanes. There are two diagnostic processes and four matched processes. Report both per-run medians, their spread, both paired candidate-minus-baseline differences and the clock log. Two repeats do not establish a tight confidence interval.

## Assets, capacity and cost

Use the existing worker image and canonical GPU tool. Build assets once and share their content root between inputs. Verify all 11 pinned cooked assets, all approved source manifests, converter bytes and dev-shell bytes before and after measurement. Fetch the approved NOAA mirror first. Require 9,370,338 bytes and SHA-256 a14135cf20fe2d0a7a18af72a0999483735c1f7e47cf3dbdc24d819beda61b04. No local art upload or new infrastructure is part of this proposal.

Stop if initial free GPU memory is below 2048 MiB. After diagnostics and both pristine builds, estimate the remaining work using that worker's observed case durations. Charge every synthetic case as the expensive independent extreme reference, include return-film prefix work, add 25% margin and reserve 20 seconds for verification. Stop before matched rounds if this estimate exceeds the remaining command time. Never retry automatically.

The proposed command cap is 840 seconds. The canonical execution cap is 900 seconds. The canonical worst-case model is (900 + 70) × $0.00016 = $0.1552. This is a maximum proposal, not spending authority or a prediction of actual cost.

Keep raw rows on the worker and collect compressed rows, logs, patches and provenance. Compressed rows may consume at most 6.5 MB of the handler's 8 MB result budget. Reserve the remainder for logs and provenance. Result size and full runtime remain uncertain until a Linux execution finishes.

## Local verification and remaining uncertainties

Local verification passed for both final immutable inputs. The identical C# fixture has SHA-256 6f04a6f6b86bcfcab97b02a8b7e2933f2b904edabf91185403eb5464931c4e53. Four builds and four smoke processes passed. Each smoke process ran native and FSR cut and ordinary lanes, giving 16 audited lane results with zero validation messages. Every one of the 605 production files in each plain archive matches its pinned commit after restoration. All three diagnostic files per archive were restored exactly, followed by successful pristine builds and recorded assembly hashes.

The observer retained two separate records for each sampled two-draw initial still call. Final observations exactly matched normal capture output. Ordinary observations read zero bytes and request no captures. Ordinary GPU frame numbers were [0, 1, 2, 3], correctly describing preceding draws. Diagnostic logs show native real rendering at 1280 × 720 and FSR at 848 × 477, with 1280 × 720 output. The fixture compiles and runs against both the baseline glossy formats and the candidate's 32-bit glossy formats.

The candidate outward cut at tick 1417 uses one scene draw and one presentation and matches its independent control in all four candidate local lanes. The baseline outward cut does not match within the observed 90 follow-up frames. This is Mac correctness evidence only. The ordinary smoke uses four synthetic frames. It does not execute the complete 120-frame real-scene ordinary lane. The local film smoke covers the outward cut, while the full proposal also includes the return and synthetic cases. See local-verification-summary.json and the per-command logs and exit files.

The previous Linux job failed during baseline diagnostics before candidate diagnostics or matched rounds. Linux acceptance remains HOLD. The allocator fix and changed glossy image formats have not completed this combined Linux comparison. Full execution within 840 seconds is unproven. Asset setup, four Host builds, reference settling, baseline recovery and measurement drift can exhaust the cap. The capacity estimate is conservative and uncalibrated.

The emitted PowerShell proposal must throw before reaching the canonical submit command. Regeneration with a new recorded parent spending decision is required before any launch. No live submit command, paid run or automatic retry is authorized here.
