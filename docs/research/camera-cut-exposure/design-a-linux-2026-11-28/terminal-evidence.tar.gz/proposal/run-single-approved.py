"""Run the verified command once and retain stdout, stderr and its real exit code."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236')
verification = json.loads((root / 'final-launch-verification.json').read_text())
assert hashlib.sha256((root / 'final-launch.ps1').read_bytes()).hexdigest() == verification['submit_command_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == verification['candidate']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo) == b''
with (root / 'single-submission-consumed.json').open('x') as stream:
    json.dump({'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'runner_pid': os.getpid(), 'authorized_submissions': 1, 'automatic_retry': False, 'verification': verification}, stream, indent=2)
command = "& '" + str(root / 'final-launch.ps1').replace("'", "''") + "'; exit $LASTEXITCODE"
with (root / 'canonical-stdout.log').open('wb', buffering=0) as stdout, (root / 'canonical-stderr.log').open('wb', buffering=0) as stderr:
    process = subprocess.Popen(['pwsh', '-NoProfile', '-Command', command], cwd=repo, stdout=stdout, stderr=stderr, env={**os.environ, 'PYTHONUNBUFFERED': '1'})
    (root / 'client-start.json').write_text(json.dumps({'pid': process.pid, 'runner_pid': os.getpid(), 'tmux_session': 'issue4-corrected-gpu-once-20261128-062955', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
    code = process.wait()
(root / 'canonical-exit.json').write_text(json.dumps({'exit': code, 'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'automatic_retry': False}, indent=2) + '\n')
raise SystemExit(code)
