"""Summarize completed matched worker measurements, without accepting incomplete evidence."""
import argparse
import gzip
import json
import math
from pathlib import Path
import statistics


def summary(values):
    if not values or not all(math.isfinite(value) for value in values):
        raise ValueError('Missing or non-finite measurements.')
    return {'n': len(values), 'median': statistics.median(values),
            'minimum': min(values), 'maximum': max(values),
            'range': max(values) - min(values),
            'sample_standard_deviation': statistics.stdev(values) if len(values) > 1 else None}


def read_rows(path):
    if not path.is_file() and not path.with_suffix(path.suffix + '.gz').is_file():
        import re
        match = re.fullmatch(r'(r[12]|diagnostic)-(before|after)-(native|fsr)-(cut|steady)', path.parent.name)
        if match:
            phase, tree, mode, lane = match.groups()
            path = path.parent.parent / (phase + '-' + tree) / mode / lane / 'rows.json'
    if path.is_file():
        return json.loads(path.read_text())
    return json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


def analyze(root):
    if json.loads((root / 'phase.json').read_text())['phase'] != 'complete':
        raise ValueError('Worker did not complete. Partial measurements are not a successful run.')
    restoration = json.loads((root / 'restoration.json').read_text())
    if not restoration['all_diagnostic_source_restored']:
        raise ValueError('Diagnostic source was not restored.')
    if json.loads((root / 'assets-before.json').read_text()) != json.loads((root / 'assets-after.json').read_text()):
        raise ValueError('Assets differ before and after measurement.')
    if json.loads((root / 'asset-source-before.json').read_text()) != json.loads((root / 'asset-source-after.json').read_text()):
        raise ValueError('Asset sources or converter differ.')
    result = {'notes': [
        'Two matched rounds are exploratory. Each run has96wall samples and95GPU samples after matching frame identities. Do not infer a confidence interval from individual frames.',
        'Report overlap and both paired differences. Repeat only with new approval if a decision remains unresolved.',
        'Presentation means completed offscreen Vulkan submission, without compositor or display scanout.',
        'Cut latency includes the equal eight-byte observation per presentation and earlier recovery capture overhead. Encoding is absent.',
        'GPU span excludes the capture pass. Continuous ordinary wall samples request no capture.',
        'Baseline reduction and adaptation share one dispatch. No independent within-dispatch timings exist.'
    ], 'steady': {}, 'cuts': {}, 'diagnostic_passes': {}, 'cold_reference_comparisons': []}
    data = {}
    for mode in ['native', 'fsr']:
        for tree in ['before', 'after']:
            medians = {'wall_ms': [], 'gpu_without_capture_ms': []}
            for repeat in [1, 2]:
                lanes = {}
                for lane in ['cut', 'steady']:
                    path = root / f'r{repeat}-{tree}-{mode}-{lane}' / 'rows.json'
                    row_file = read_rows(path)
                    if row_file['Validate']:
                        raise ValueError('Timed row ran with validation enabled.')
                    if tree == 'after' and row_file['MeterBins'] != 2304:
                        raise ValueError('Candidate did not use the 2304-bin meter.')
                    lanes[lane] = row_file
                data[mode, tree, repeat] = lanes
                steady = [row for row in lanes['steady']['Rows'] if row.get('Kind') == 'steady' and row['Measured']]
                if len(steady) != 96:
                    raise ValueError('Expected 96 ordinary frames after 24 warmup frames.')
                frames = [row['Frame'] for row in steady]
                if lanes['steady']['ObservationBytesPerPresentation'] != 0:
                    raise ValueError('Ordinary lane enabled presentation readback.')
                if any(frame['Draws'] != 1 or frame['Presentations'] != 1 for frame in frames):
                    raise ValueError('Ordinary control made extra scene draws or presentations.')
                gpu = []
                # An uncaptured render reports the previous draw's GPU timings.
                # Keep only GPU frame identities inside the measured wall-frame interval.
                first_measured_gpu_frame = steady[0]['Draws'] - steady[0]['Frame']['Draws']
                for frame in frames:
                    if frame['GpuMilliseconds'] is None or not frame['Passes']:
                        raise ValueError('Missing Vulkan timestamps.')
                    if frame['GpuFrame'] >= first_measured_gpu_frame:
                        gpu.append(frame['GpuMilliseconds'] - sum(
                            timing['Milliseconds'] for timing in frame['Passes'] if timing['Pass'] == 'capture'))
                    if frame['CaptureRequested']:
                        raise ValueError('Ordinary lane requested a pixel capture.')
                if len(gpu) != 95:
                    raise ValueError('Expected95GPU observations after excluding the final warmup timing and unavailable last timing.')
                if len({frame['GpuFrame'] for frame in frames}) != len(frames):
                    raise ValueError('GPU records repeat an earlier frame.')
                medians['wall_ms'].append(statistics.median(
                    (frame['EndAt'] - frame['StartAt']) * 1000 / lanes['steady']['Frequency'] for frame in frames))
                medians['gpu_without_capture_ms'].append(statistics.median(gpu))
                cuts = [row for row in lanes['cut']['Rows'] if row.get('Kind') == 'cut']
                if len(cuts) != 8:
                    raise ValueError('Missing cut/control case.')
                for cut in cuts:
                    key = mode + '/' + tree + '/' + cut['Label']
                    if tree == 'after' and '-continuous-' not in cut['Label']:
                        if cut['TotalShadingDrawsFirstApi'] != 1 or cut['FirstApiPresentations'] != 1:
                            raise ValueError('Candidate used hidden repeated scene rendering.')
                    result['cuts'].setdefault(key, []).append({
                        'round': repeat, **{name: cut[name] for name in [
                            'FirstPresentationMilliseconds', 'FirstEnqueueMilliseconds', 'FirstApiReturnMilliseconds',
                            'FirstApiCorrect', 'FirstPresentationCorrect', 'CorrectMilliseconds', 'RightCensored',
                            'TotalShadingDrawsFirstApi', 'TotalShadingDrawsObserved', 'CorrectDraws',
                            'CorrectPresentations', 'FirstApiPresentations', 'ExactFirstPresentationAttribution',
                            'FollowupFramesObserved', 'CorrectFollowupFrames', 'CorrectSnapshotSeconds']}})
            result['steady'][mode + '/' + tree] = {
                metric: {'runs': values, **summary(values)} for metric, values in medians.items()}
        for repeat in [1, 2]:
            cold = {}
            for tree in ['before', 'after']:
                cold[tree] = [row for row in data[mode, tree, repeat]['cut']['Rows']
                              if row.get('Kind') == 'cold-reference']
            if len(cold['before']) != len(cold['after']):
                raise ValueError('Different cold-reference populations.')
            for before, after in zip(cold['before'], cold['after']):
                a, b = before['Last'], after['Last']
                result['cold_reference_comparisons'].append({'mode': mode, 'round': repeat,
                    'case': {key: before[key] for key in ['Label', 'source', 'destination', 'compensation', 'control'] if key in before},
                    'stops_delta': b['Stops'] - a['Stops'],
                    'center_rgb_delta': [y - x for x, y in zip(a['Center'], b['Center'])],
                    'within_tolerance': abs(b['Stops'] - a['Stops']) <= 1/16
                        and all(abs(y-x) <= 2 for x,y in zip(a['Center'], b['Center']))})
        for tree in ['before', 'after']:
            for lane in ['cut', 'steady']:
                diagnostic = read_rows(root / f'diagnostic-{tree}-{mode}-{lane}' / 'rows.json')
                timings = {}
                frames = []
                for row in diagnostic['Rows']:
                    if row.get('Kind') == 'steady' and row['Measured']:
                        frames.append(row['Frame'])
                    elif row.get('Kind') == 'cut':
                        frames.append(row['Frames'][0]['Frame'])
                for frame in frames:
                    for timing in frame['Passes']:
                        name = timing['Pass']
                        if name.startswith('linux ') or name in ['exposure', 'exposure adapt']:
                            timings.setdefault(name, []).append(timing['Milliseconds'])
                result['diagnostic_passes'][mode + '/' + tree + '/' + lane] = {
                    name: summary(values) for name, values in timings.items()}
    result['paired_steady_deltas'] = {}
    for mode in ['native', 'fsr']:
        for metric in ['wall_ms', 'gpu_without_capture_ms']:
            before = result['steady'][mode + '/before'][metric]['runs']
            after = result['steady'][mode + '/after'][metric]['runs']
            result['paired_steady_deltas'][mode + '/' + metric] = {
                'candidate_minus_baseline': [b-a for a,b in zip(before,after)],
                'median_delta': statistics.median(after) - statistics.median(before),
                'median_percent': 100 * (statistics.median(after) / statistics.median(before) - 1),
                'all_runs_separate': max(before) < min(after) or max(after) < min(before)}
    result['candidate_first_presentations_correct'] = all(
        row['FirstPresentationCorrect'] for key, rows in result['cuts'].items()
        if '/after/' in key and '-continuous-' not in key for row in rows)
    result['correctness_reference_agreement'] = all(
        item['within_tolerance'] for item in result['cold_reference_comparisons'])
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    args.out.write_text(json.dumps(analyze(args.root), indent=2) + '\n')
