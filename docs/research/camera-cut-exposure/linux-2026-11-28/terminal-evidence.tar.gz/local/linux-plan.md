# Issue #4 Linux measurement draft

This revision compiles and smoke-checks the external harness in plain source archives of the two immutable commits. It changes no shared checkout source, index or assemblies. It submits no job and publishes no source. Local smoke results establish harness behavior on MoltenVK. They establish no Linux rendering performance result.

## Inputs and output boundaries

| Input | Value |
|---|---|
| Baseline after C1 | `19e17c5ba364392ca6bf84b00c11a7d709771ded` |
| Baseline tree | `70737af29b08536ded3369336b36fa04116f29b1` |
| Candidate seed | `cf84f02bc5fabfedb22c2b17835ae0d194c4cb91` |
| Final candidate | `a7a78944450584ad1c2ed2d0f3d38c583d80725c`, integrated and pushed to both remotes. Production source matches the validated seed. |
| Linux device | NVIDIA RTX 2000 Ada Generation, driver `595.112.07`, one worker for both trees and all matched rounds |
| Content | One absolute `TERTIUS_CONTENT_ROOT` for both trees and every run |
| Cooked Linux manifest SHA-256 | `210510fe09f7195174b57d4491223a5721fc03c6a33325b4e24bbf0063319f75` |

The old source-bundle measurements already exist. This comparison isolates issue #4 against the final issue #3 source. The worker applies no behavior fix. It must never copy the legacy exposure-buffer barrier into the analytic raw meter. The final integration retains the analytic meter without the legacy exposure read.

A presentation means completion of the real offscreen Vulkan submission. The wrapper records submission return, waits for that submission's fence, then records completion. This boundary excludes a compositor, vblank and display scanout.

A correct destination presentation uses exposure within 1/16 stop and center RGB codes within two of the independently settled cold reference. One stop doubles exposure. RGB codes range from 0 to 255. These checks follow the existing film exposure tests. They do not establish whole-image perceptual equality.

## Observe every presentation

The cut lane observes every submitted draw, including internal warmup draws. Its `IOutputTarget.FinishRecording` appends two copies to that draw's existing command buffer: the applied exposure and the center output pixel. They occupy eight bytes of host-visible storage. After the submission fence completes, the wrapper reads those bytes and records them with that presentation's completion timestamp.

The exposure copy region is exactly:

```csharp
            var applied = new BufferCopy(srcOffset: 4, dstOffset: 0, size: 4);
```

where

- `applied` describes one GPU buffer-copy region.
- `BufferCopy` is Vulkan's description of source byte offset, destination byte offset and byte count.
- `srcOffset: 4` reads the exposure buffer's `previousStops` float. After the final exposure pass, it holds the exposure used by that presentation, in both pinned implementations.
- `dstOffset: 0` writes the first four bytes of measurement storage.
- `size: 4` copies one 32-bit float.

The other four bytes hold the output pixel's RGBA codes. These are actual sRGB output bytes. The observer adds no presentation or scene shading. It uses normal resource barriers for its copies and leaves production behavior unchanged. Each captured API call checks that its final presentation observation exactly equals its normal exposure readback and captured center pixel. A discrepancy fails the harness.

The smoke evidence records APIs that submit two distinct presentations. Both observations survive, even though the ordinary capture sink receives only the final image. Thus first-presentation correctness no longer depends on the final capture. Time to correct searches individual presentation records from the cut request onward.

The ordinary lane allocates no observation storage, records no observation copy and requests no pixel capture. Its raw frame record states whether a capture was requested. The graph still has a named capture pass, even when that pass records no work. Its name alone does not prove readback occurred.

| Quantity | Start | End | Included and excluded |
|---|---|---|---|
| First-presentation latency, wall ms | Before the public camera command, or before the synthetic light/cut change | Completion of the first destination submission | Includes command validation, camera assignment, next film tick, snapshot publication, CPU recording, hidden draws, GPU work, capture copy and equal eight-byte observation. Excludes CPU delivery after that completion. |
| Time to correct presentation, wall ms | The same cut request | Completion of the first individually observed correct presentation | Includes intervening internal draws and capture calls. Includes CPU delivery and measurement work from earlier presentations. No encoding. |
| First API return latency, wall ms | The same cut request | Return from the first destination render/capture call | Includes capture readback and center-pixel delivery. No PNG or video encoding. |
| Total scene-shading draws | Draw count before the request | First API return, first correct presentation, and observed run end, separately | Counts every full `DrawFrame`, including hidden baseline warmups. It is not a count of material draw commands. |
| Ordinary wall cost, ms | Before `VulkanRenderer.Render` | Return after its output fence completes | Includes CPU recording, submission and GPU completion. Excludes world tick, snapshot publication, observation, requested capture and encoding. One frame in flight gives serialized render cost. |
| Ordinary GPU cost, ms | First graph timestamp | Last graph timestamp, excluding the named capture interval | Uses continuous ordinary frames from pristine production code. Records frame identity to avoid counting repeated stale timing samples. |
| Exposure dispatch costs, GPU ms | Diagnostic timestamp boundaries | Next diagnostic boundary | Includes barriers and descriptor setup in each interval. These diagnostic numbers include additional timestamps. They do not supply ordinary frame acceptance numbers. |

Baseline histogram reduction and adaptation share one dispatch. Report **reduction + adapt** as a combined cost. No independent within-dispatch GPU timings exist. The candidate also has a separately timed cut initialization dispatch and a final cut phase. Histogram clear and metering have separate intervals.

## Cases and references

| Case | Incoming history | Destination and control |
|---|---|---|
| Outside cut | Original public film prefix, including the seat-tail frames | First outside frame at tick 1417. Separate cold outside-control renderer/world. |
| Return cut | Original prefix, including all 45 outside film frames | First return frame at tick 1462. Separate cold return-control renderer/world. |
| Ordinary cut, history one | Ramp under 1361 W/m², eight source still captures | Same ramp under 0.001 W/m². Independent cold destination. |
| Ordinary cut, history two | Ramp under 3 W/m², eight source still captures | Same destination. Reuses the independently settled destination reference, rather than building it again. |
| Extreme cut, history one | Ramp under 1361 W/m², compensation −13 stops | Same ramp under 1e-12 W/m². Independent cold destination. |
| Extreme cut, history two | Ramp under 3 W/m², compensation −13 stops | Same extreme destination. Reuses its independent reference. |
| Fixed exposure | Ramp under 1361 W/m², fixed exposure −2 stops | Cut to 0.001 W/m². Independent fixed-exposure destination reference. |
| Continuous frame handoff | Ramp under 1361 W/m² | Change to 0.001 W/m² and reference frame 8, retaining the cut count. Records gradual adaptation. |

The extreme cold reference uses one initial capture plus 64 further still captures. Other cold references use one initial capture plus eight further captures, matching the existing public fixture. The last two must agree within both tolerances. Failure invalidates the reference. Never use the tested first frame as its own reference.

Each tree produces its own independent references. The analyzer also compares those references across trees. A disagreement blocks a shared correctness conclusion. References share no state across trees, output modes or exposure settings.

After the first destination image, recovery holds its scene pose fixed and advances only snapshot time by 1/60 s per follow-up frame. The worker renders without real-time pacing. Record wall latency, follow-up frame count and snapshot seconds separately. Stop after **90** follow-up frames. A baseline that remains wrong is right-censored at that limit. Preserve its first-presentation latency and report that time to correct was not observed. This expected baseline outcome does not fail the run.

Ordinary timing continues the real world from the seat-tail prefix, without camera changes, by one world tick per frame. Record 120 frames. Discard the first 24 and summarize the remaining 96 wall samples. An uncaptured render reports the preceding draw's GPU timing. The analyzer matches GPU frame identities to the measured interval, which leaves 95 GPU samples. It excludes the final warmup draw's timing and does not invent a timing for the last draw. This warmup replaces the draft's separate warmup processes.

The fixture uses the public `Script`, `ScriptRunner`, `FilmStep`, `IPlayback` and snapshot publication path. One-step script execution places the request timestamp before the camera command without a production hook. The capture sink keeps only a center pixel in memory. No PNG or video files are generated by the smoke or planned measurement.

## Dimensions and source restoration

| Family | Output | Native active size | Requested FSR scale | FSR active size |
|---|---:|---:|---:|---:|
| Released scene | 1280 × 720 | 1280 × 720 | 2/3 | 848 × 477 |
| Synthetic ramp | 160 × 90 | 160 × 90 | 2/3 | 96 × 54 |

The renderer rounds the scale down to whole steps of the output's reduced aspect ratio. These are the expected active sizes, rather than componentwise 2/3 rounding.

Both trees use Release, one frame in flight, no output dither, per-pass timestamps, the headless film clock and zero optional screen-trace warmup frames. Other production renderer defaults, including bloom, remain enabled. Mandatory exposure warmups still count. Diagnostic runs enable validation. Matched runs disable validation equally.

For diagnostics only, source probes log pending `RenderSize` and `OutputSize` at `CommitDrawnFrame` and add exposure dispatch timestamps. The worker records the exact diffs. It checks actual real and synthetic dimensions in each tree and mode. It requires the candidate's 2304-bin meter and reports the unchanged baseline bin count.

Restore all three instrumented production files byte for byte and require an empty tracked diff. Then rebuild pristine production assemblies before any matched run. Record assembly hashes. The same generated test fixture remains in both trees. Ordinary timing disables its presentation observer.

## Assets and execution

1. Verify identical dev shell, source sidecars and converter hashes in both trees.
2. Fetch the approved NOAA mirror first. Require 9,370,338 bytes and SHA-256 `a14135cf20fe2d0a7a18af72a0999483735c1f7e47cf3dbdc24d819beda61b04`.
3. Run `bash tools/blue-danube-assets/setup.sh --staging <absolute folder>` once in the baseline tree. This is the existing entry point. There is no `tools/setup-assets.py --staging-sources` entry point here.
4. Verify the approved cached sources, ten cooked GLBs and Earth material.zip. Require the pinned Linux cooked manifest.
5. Set one absolute content root for both trees and all runs. Verify cached sources, cooked files and converter hashes again at the end.

The source and converter provenance comes from the successful staged-mirror job `d03d314f-0fdc-475d-8bd2-19ea3388a6a6-u2`. No art upload, graybox content, new infrastructure or approval-manifest edit is needed.

The revised proposed job has **four builds and six test processes**:

| Phase | Builds | Processes | Scope |
|---|---:|---:|---|
| Baseline diagnostics | 1 | 1 | Native and FSR. Outside cut, extreme cut, and ordinary frames. |
| Baseline restoration | 1 | 0 | Restore source and rebuild pristine assemblies. |
| Candidate diagnostics | 1 | 1 | Same diagnostic cases. |
| Candidate restoration | 1 | 0 | Restore source and rebuild pristine assemblies. |
| Capacity check | 0 | 0 | Project remaining work from this worker's diagnostic case durations. Stop if it exceeds remaining time. |
| Matched round 1 | 0 | 2 | Baseline then candidate. Each process covers both modes, all eight cut/control cases and ordinary frames. |
| Matched round 2 | 0 | 2 | Candidate then baseline, same scope. |

This preserves two reversed matched repeats per tree and mode. It removes 22 process starts from the draft, removes separate warmup runs, and avoids redundant destination reference renderers within each mode. It does not rerun the old source-bundle benchmark or the 201 existing game PNG captures.

## Runtime and spending proposal

Propose at most one canonical GPU job, with an 840 s command cap and 900 s execution cap. The canonical cost model gives `(900 + 70) × $0.00016 = $0.1552` worst case. This requires explicit issue #4 approval. Issue #3 authority does not carry over. No retry, second job or publication is implicit.

Prior Linux evidence gives a useful floor for planning:

| Prior work | Observed worker seconds |
|---|---:|
| One canonical asset setup | 153.229 |
| Two first diagnostic Demo builds | 58.75 + 48.31 |
| Two pristine Demo rebuilds | 4.30 + 3.85 |
| Total of those phases | 268.439 |

The Host test builds can cost more than those Demo builds. These prior observations leave about 571 s of the 840 s command cap before additional source/device checks, diagnostics and measurements. The complete revised suite has not run on Linux. Local smoke timings must not be substituted for Linux frame-time or FPS evidence.

The worker therefore measures whole diagnostic case durations on its actual card. It projects two remaining visits for every tree/mode. Each visit charges two outside-case costs for the two real cuts, six extreme-case costs for the synthetic/control cases, one ordinary-case cost, 45 additional real draws for the return prefix, and two seconds of extra control work. It adds 25% margin and 20 seconds for final verification. This deliberately overcounts reference reuse. `capacity.json` records every input and the remaining command time.

If that estimate exceeds the remaining time, stop **before** matched rounds, retain diagnostic evidence and return an incomplete result. The canonical hard timeout remains the outer bound. The projection is conservative but uncalibrated. It is not a guarantee that work fits. Full 840 s feasibility remains an explicit uncertainty for coordinator judgment, rather than a success claim.

An alternative split or further reduction needs a revised concrete plan and new approval. The worker does not choose or launch one itself.

Use each run's median as one observation. Report both run medians, their range, sample standard deviation and both paired candidate-minus-baseline differences. Do not treat 96 frames as 96 independent repeats. With two repeats, report overlap and the clock log instead of a tight confidence interval.

## Artifacts and commands

| File | Role |
|---|---|
| `linux-fixture.py` | Same generated C# source for both trees, with batching and per-presentation observation. |
| `linux-worker.py` | Asset setup, diagnostic hooks, restoration, capacity gate and six-process schedule. |
| `linux-local-validate.py` | Local Nix compilation and minimal smoke in plain immutable source archives. |
| `linux-analyze.py` | Reads raw or gzip rows, checks completeness and summarizes matched measurements. |
| `linux-config.json` | SHA/device/content pins, false approval fields and capped proposed job. |
| `linux-emit-job.py` | Emits a PowerShell launch command and payload hashes. Never executes it. |
| `linux-validation-summary.json` | Actual build, CLI, smoke and restoration evidence from this resumed preparation. |
| `linux-file-hashes.json` | Hashes of current scripts, plan and evidence. |
| `linux-preflight-current.json` | Durable phase, slot status and remaining gaps. |

The candidate is pinned. After coordinator review and explicit issue #4 approval, the owner may emit the launch command:

```powershell
python3 -B -I '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/linux-emit-job.py' --config '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/linux-config.json' --repo '/Users/alexispurslane/.t3/worktrees/tertius/t3-042655f4-5c326eb10494e236' --out '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/linux-submit.ps1'
```

It uses only the existing canonical submit tool, image routing, dev shell and caps. No launch command has been emitted or run. The ticket lead integrated main and verified publication to both remotes. The parent owns coordinator acceptance and paid submission.

Return device/clock CSVs, command records, active extents, exact diagnostic diffs, source/asset manifests, pristine assembly hashes, `capacity.json`, and compressed raw rows. Gzip keeps rows within the handler's 8 MB returned-result cap. The worker refuses completion if row gzip files alone exceed 6.5 MB.

After retrieval:

```powershell
python3 -B -I '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/linux-analyze.py' '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/linux-run-final/linux-out' --out '/Users/alexispurslane/Movies/Blue Danube/exposure-bloom-recovery/issue-4-evidence/linux-statistics.json'
```

The final report must separate first presentation, first correct presentation, API return and ordinary GPU cost. Preserve incorrect baseline results and right-censored recovery. Record both actual cut ticks, every history/control, all scene draws, dimensions and meter costs.

## Remaining uncertainties

- The final candidate is `a7a78944450584ad1c2ed2d0f3d38c583d80725c`. Local validation covers the exact baseline and seed candidate APIs. Production source in the final candidate matches the seed byte for byte.
- The full revised suite and its capacity model have not run on the Linux worker. Completion within 840 s is not established.
- The complete Linux cold-reference population must settle and agree. Local smoke covers only the extreme synthetic case and a minimal public outside cut.
- Two matched repeats provide a bounded comparison. They may not separate a small cost change from run-to-run spread.
- Coordinator acceptance and explicit issue #4 paid approval remain absent. No measurement-success or submission-readiness claim follows from local smoke.
